/*
 * Copyright (c) 2023-2025. Phasmid Software
 */

package com.phasmidsoftware.number.expression.expr

import cats.implicits.catsSyntaxEq
import com.phasmidsoftware.number.algebra.core.*
import com.phasmidsoftware.number.algebra.eager
import com.phasmidsoftware.number.algebra.eager.{Angle, Complex, Eager, InversePower, Nat, NaturalExponential, Number, RationalNumber, Real, Scalar, WholeNumber}
import com.phasmidsoftware.number.algebra.util.LatexRenderer
import com.phasmidsoftware.number.core.inner.{Factor, Rational}
import com.phasmidsoftware.number.core.numerical
import com.phasmidsoftware.number.core.numerical.Field
import com.phasmidsoftware.number.expression.expr.Expression.em

import scala.language.implicitConversions

/**
  * Represents an abstract expression for a Valuable that can optionally be associated with a name.
  *
  * A `ValueExpression` provides methods for evaluating its qualifications within
  * a given context, rendering its representation, and determining equality or hashing.
  * It extends the `AtomicExpression` trait, allowing it to be used wherever atomic
  * expressions are valid.
  *
  * CONSIDER placing maybeName in the second parameter list.
  *
  * @param value     the `Valuable` associated with the expression
  * @param maybeName an optional name for the Valuable expression
  */
sealed abstract class ValueExpression(val value: Eager, val maybeName: Option[String] = None) extends AtomicExpression {
  /**
    * Method to determine what `Factor`, if there is such, this `Structure` object is based on.
    *
    * @return an optional `Factor`.
    */
  def maybeFactor(context: Context): Option[Factor] =
    value.maybeFactor(context)

  /**
    * Determines if the current number is equal to zero.
    *
    * @return true if the number is zero, false otherwise
    */
  def isZero: Boolean = value.isZero

  /**
    * Determines the sign of the Structure value represented by this instance.
    * Returns an integer indicating whether the value is positive, negative, or zero.
    *
    * @return 1 if the value is positive, -1 if the value is negative, and 0 if the value is zero
    */
  def signum: Int = value.signum

  /**
    * Determines whether this object represents unity.
    *
    * @return true if the object represents unity, false otherwise
    */
  def isUnity: Boolean = value.isUnity

  /**
    * Method to determine if this Structure object is exact.
    * For instance, `Number.pi` is exact, although if you converted it into a PureNumber, it would no longer be exact.
    *
    * @return true if this Structure object is exact in the context of No factor, else false.
    */
  def isExact: Boolean = value.isExact

  /**
    * If this `Valuable` is exact, it returns the exact value as a `Double`.
    * Otherwise, it returns `None`.
    * NOTE: do NOT implement this method to return a Double for a fuzzy Real--only for exact numbers.
    *
    * @return Some(x) where x is a Double if this is exact, else None.
    */
  def maybeDouble: Option[Double] = value.maybeDouble

  /**
    * Applies the given `ExpressionMonoFunction` to the current context of the `ValueExpression`
    * and attempts to produce an atomic expression as its result.
    * NOTE that, if there is a result defined, it is exact and, preferably, a `ValueExpression`.
    *
    * @param f the `ExpressionMonoFunction` to be applied. This function determines how the
    *          evaluation will transform the current `ValueExpression` into a potential result.
    * @return an `Option` containing a `ValueExpression` if the evaluation succeeds,
    *         or `None` if the evaluation fails.
    */
  def monadicFunction(f: ExpressionMonoFunction): Option[ValueExpression]

  /**
    * Evaluates the current Valuable expression within the given context and determines
    * if the Valuable qualifies based on the context's rules.
    *
    * NOTE: we now have Valuable values that may not have a unique factor (Algebraics).
    * That's why we need to check first if value has a unique factor.
    *
    * If the Valuable meets the qualifications specified by the context, the method
    * returns an `Option` containing the Valuable. Otherwise, it returns `None`.
    *
    * @param context the context in which the Valuable is evaluated. It defines the
    *                qualification rules for determining whether the Valuable is valid.
    * @return `Some(Valuable)` if the Valuable qualifies within the given context, otherwise `None`.
    */
  def evaluate(context: Context): Option[Eager] =
    if (context.valuableQualifies(value))
      Some(value) // NOTE probably not a good idea to invoke normalize here.
    else
      value match {
        case nat: Nat =>
          Some(nat)
        case normalizable: CanNormalize[?] =>
          // CONSIDER putting the conditional in the pattern
          Option.when(normalizable.maybeFactor(context).isDefined && context.valuableQualifies(normalizable))(normalizable.normalize)
        case eager: Eager =>
          // CONSIDER putting the conditional in the pattern
          Option.when(eager.maybeFactor(context).isDefined && context.valuableQualifies(eager))(value)
      }

  /**
    * Provides an approximation of this number, if applicable.
    *
    * This method attempts to compute an approximate representation of the number
    * in the form of a `Real`, which encapsulates uncertainty or imprecision
    * in its value. If no meaningful approximation is possible for the number, it
    * returns `None`.
    *
    * @return an `Option[Real]` containing the approximate representation
    *         of this `Number`, or `None` if no approximation is available.
    */
  def approximation(force: Boolean): Option[Real] = value match {
    case r: Real =>
      Some(r)
    case eager =>
      eager.approximation(force)
  }

  /**
    * Provides an approximation of the `ValueExpression` as an `Eager`, if applicable.
    *
    * This method checks if the associated `value` is an instance of `eager.Complex`.
    * If it is, the method directly returns it wrapped in an `Option`. Otherwise, it
    * delegates to the `approximation` method to compute a possible approximation.
    *
    * @param force a Boolean flag indicating whether the approximation should be forced.
    *              If true, the method may attempt a broader range of approximations.
    *              Defaults to false.
    *
    * @return an `Option[Eager]` containing the approximation if one exists, or `None`
    *         if an approximation is not available or applicable.
    */
  override def approximationComplex(force: Boolean = false): Option[Eager] = value match {
    case c: eager.Complex => Some(c)
    case _ => approximation(force)
  }

  /**
    * Method to render this Structure in a presentable manner.
    *
    * @return a String
    */
  lazy val render: String = maybeName getOrElse value.render

  /**
    * Generate a String for debugging purposes.
    * The name is enclosed in square brackets to distinguish such values from the other Literals.
    *
    * @return a String representation of this Literal.
    */
  override def toString: String =
    lazy val string = s"[${value.show}]"
    s"${maybeName getOrElse string}"

  /**
    * Compares this `ValueExpression` with another object for equality.
    * The comparison considers the `value` Valuable and whether the other object can
    * be equal to this instance.
    *
    * @param other the object to compare for equality with this instance.
    * @return true if the provided object is equal to this instance, false otherwise.
    */
  override def equals(other: Any): Boolean = other match {
    case that: ValueExpression =>
      (this eq that) || (that.canEqual(this) && value === that.value)
    case _ =>
      false
  }

  /**
    * Computes the hash code for this `ValueExpression` instance.
    *
    * The hash code is derived from the hash code of the `value` Valuable, ensuring
    * that the behavior adheres to the contract of the `hashCode` method,
    * particularly in relation to the `equals` method.
    *
    * @return an integer hash code that represents this `ValueExpression` instance.
    */
  override def hashCode(): Int = value.hashCode()

  /**
    * Determines whether the provided object can be considered equal to an instance of `ValueExpression`.
    *
    * @param other the object to compare with this instance.
    * @return true if the provided object is an instance of `ValueExpression`, false otherwise.
    */
  private def canEqual(other: Any): Boolean =
    other.isInstanceOf[ValueExpression]
}

/**
  * The `ValueExpression` companion object provides a mechanism to extract elements from a `ValueExpression` instance.
  * It defines the `unapply` method to enable pattern matching and decomposition of `ValueExpression` objects.
  *
  * The extraction operation retrieves the underlying `Eager` and an optional name, if available.
  * It handles two main cases:
  * 1. For instances of `Literal`, it extracts the `Eager` value along with `None` for the optional name.
  * 2. For other cases, it extracts the `Eager` value along with its associated optional name.
  *
  * @see ValueExpression
  * @see Literal
  */
object ValueExpression {

  /**
    * Creates a `ValueExpression` instance by wrapping the provided `Valuable` object.
    *
    * @param v the `Eager` instance to be encapsulated within a `ValueExpression`.
    * @return a `ValueExpression` representing the provided `Eager` object, with its rendered representation.
    */
  def apply(v: Eager): ValueExpression = Literal(v, Some(v.render))

  /**
    * Creates a Literal instance using an integer value.
    * NOTE not recursive
    *
    * @param x the integer value to be used for constructing the Literal.
    * @return a Literal instance wrapping the provided integer value as a Real number.
    */
  def apply(x: Int): ValueExpression = x match {
    case 0 => Zero
    case 1 => One
    case -1 => MinusOne
    case 2 => Two
    case _ => ValueExpression(WholeNumber(x))
  }

  /**
    * Extracts components from a `ValueExpression` instance, enabling pattern matching.
    *
    * The `unapply` method decomposes a `ValueExpression` into its constituent `Valuable` and an
    * optional name. For instances of `Literal`, the optional name is always `None`.
    *
    * @param f the `ValueExpression` to be decomposed.
    * @return an `Option` containing a tuple of the `Valuable` and an optional name derived
    *         from the given `ValueExpression`. If the input cannot be decomposed, returns `None`.
    */
  def unapply(f: ValueExpression): Option[(Eager, Option[String])] = f match {
    case Literal(x, _) =>
      Some((x, None))
    case _ =>
      Some((f.value, f.maybeName))
  }

  /**
    * LatexRenderer for ValueExpression expressions.
    *
    */
  implicit val valueExpressionLatexRenderer: LatexRenderer[ValueExpression] = LatexRenderer.instance { ve =>
    ve.maybeName.getOrElse(implicitly[LatexRenderer[Eager]].toLatex(ve.value))
  }
}

/**
  * A `ValueExpression` based on a literal `Valuable`.
  *
  * @param value     the `Valuable`.
  * @param maybeName an optional name (typically this will be None).
  */
case class Literal(override val value: Eager, override val maybeName: Option[String] = None) extends ValueExpression(value, maybeName) {

  /**
    * Attempts to simplify literal expressions within the `Expression` context by matching against predefined constants.
    * The method pattern matches on the literal values and maps them to their corresponding simplified representations:
    * - `Valuable.zero` maps to `Zero`
    * - `Valuable.one` maps to `One`
    * - `Valuable.minusOne` maps to `MinusOne`
    * - `Valuable.two` maps to `Two`
    * - `Valuable.half` maps to `Half`
    * - `Valuable.pi` maps to `Pi`
    * - `Valuable.e` maps to `E`
    * - `Constants.i` maps to `I`
    * - `Valuable.infinity` maps to `Infinity`
    *
    * If the input does not match any supported constants, it returns a miss indicating the inability to simplify.
    *
    * @return an `em.AutoMatcher[Expression]` that simplifies literal constants to their predefined values
    *         or returns a miss if no simplification is applicable.
    */
  def simplifyAtomic: em.AutoMatcher[Expression] = em.Matcher[Expression, Expression]("Literal:simplifyAtomic") {
    case IsEager(Eager.zero) =>
      em.Match(Zero)
    case IsEager(Eager.one) =>
      em.Match(One)
    case IsEager(Eager.minusOne) =>
      em.Match(MinusOne)
    case IsEager(Eager.two) =>
      em.Match(Two)
    case IsEager(Eager.half) =>
      em.Match(Half)
    case IsEager(Eager.pi) | IsEager(Angle.pi) =>
      em.Match(Pi)
    case IsEager(Eager.e) =>
      em.Match(E)
    case IsEager(RationalNumber(r, _)) if r.isWhole =>
      em.Match(Literal(WholeNumber(r.toBigInt)))
    case IsEager(Eager.infinity) =>
      em.Match(Infinity)
    case x =>
      em.Miss("simplifyAtomic: cannot be simplified", x)
  }

  /**
    * Applies the given `ExpressionMonoFunction` to the current context of the `ValueExpression`
    * and attempts to produce an atomic result.
    *
    * @param f the `ExpressionMonoFunction` to be applied. This function determines how the
    *          evaluation will transform the current `ValueExpression` into a potential result.
    * @return an `Option` containing an `ValueExpression` if the evaluation succeeds,
    *         or `None` if the evaluation fails.
    */
  def monadicFunction(f: ExpressionMonoFunction): Option[ValueExpression] =
    doMonoFunction(f).map(Literal(_))

  /**
    * Applies a given `ExpressionMonoFunction` to the current value and attempts to produce an `Eager` result.
    * The evaluation depends on matching the function and the value against specific cases.
    *
    * @param f the `ExpressionMonoFunction` to be applied. This function determines the behavior
    *          of the evaluation and how the current value will be transformed into a potential result.
    * @return an `Option` containing the resulting `Eager` if the function and value evaluation succeed,
    *         or `None` if the evaluation is not applicable or fails.
    */
  private def doMonoFunction(f: ExpressionMonoFunction): Option[Eager] = (f, value) match {
    case (Negate, r: CanAddAndSubtract[?]) =>
      Some(-r)
    case (Reciprocal, r: InversePower) =>
      r.pow(WholeNumber.minusOne)
    case (Reciprocal, r: CanMultiplyAndDivide[Number] @unchecked) =>
      import Number.NumberIsMultiplicativeGroup
      Some(r.reciprocal)
    //      case (Reciprocal, a: Algebraic) =>
    //            (a.invert)
    case (Reciprocal, c: Complex) =>
      // TODO asInstanceOf
      Some(Complex(c.complex.invert.asInstanceOf[numerical.Complex]))
    case (function, q) if q.isExact =>
      function.applyExact(q)
    case _ =>
      None
  }
}

/**
  * Companion object for the `Literal` class, providing factory methods and pattern matching support.
  */
object Literal {

  /**
    * Converts the given integer value into a `Literal` object with a `WholeNumber` representation AND a name.
    *
    * @param x the integer value to be converted
    * @return a `Literal` containing the `WholeNumber` representation of the input integer
    */
  def apply(x: Int): Literal = Literal(WholeNumber(x), Some(x.toString))

  /**
    * Creates a Literal instance from a Rational value.
    *
    * @param x the Rational value to be wrapped in a Literal
    * @return a Literal instance containing the given Rational value encapsulated in a Real
    */
  def apply(x: Rational): Expression = x match {
    case Rational.zero => apply(0)
    case Rational.one => apply(1)
    case Rational.two => apply(2)
    case Rational.half => apply(RationalNumber.half, Some("\u00BD"))
    case Rational.negOne => apply(-1)
    case r => apply(RationalNumber(r).normalize)
  }

  /**
    * Creates a new Literal instance wrapping the given Double value.
    *
    * @param x the Double value to be wrapped in the Literal.
    * @return a Literal instance containing the provided Double value as a Real.
    */
  def apply(x: Double): Literal =
    Literal(Real(x))

  /**
    * Creates a Literal instance from a given number.
    *
    * @param x the number to convert into a Literal
    * @return a Literal instance representing the given number
    */
  def apply(x: numerical.Number): Expression = x match {
    case numerical.Number.one =>
      One
    case numerical.Number.zero =>
      Zero
    case numerical.Number.pi =>
      Pi
    case numerical.Number.two =>
      Two
    case numerical.Number.negOne =>
      MinusOne
    case numerical.Number.half =>
      Half
    case numerical.Number.e =>
      E
    case _ =>
      ValueExpression(Scalar(x))
  }

  /**
    * Creates a `Literal` instance wrapping the provided `Valuable` object and associates it with a name.
    *
    * @param x the `Valuable` instance to be wrapped within an optional `Literal`.
    * @return an `Option[Literal]` containing the created `Literal` if successful, or `None` otherwise.
    */
  def someLiteral(x: Eager): Option[Literal] = Some(Literal(x, Some(x.render)))

  /**
    * Extracts a Valuable value from a Literal instance.
    * CONSIDER this may never be invoked.
    *
    * @param arg the Literal instance to extract the Valuable from.
    * @return an Option containing the extracted Valuable, or None if extraction is not possible.
    */
  def unapply(arg: Literal): Option[(Eager, Option[String])] =
    Some(arg.value, arg.maybeName)

}

/**
  * Represents a specific constant whose value is a `Valuable` with an associated name.
  *
  * This abstract class extends [[ValueExpression]], allowing for named representation
  * of constants in mathematical expressions, while being tied to a specific Valuable type.
  *
  * @constructor Creates a named constant within the context of the provided Eager.
  * @param x    the mathematical Valuable to which this constant belongs.
  * @param name the name associated with this constant.
  */
sealed abstract class NamedConstant(x: Eager, name: String) extends ValueExpression(x, Some(name)) {
  /**
    * Returns a string representation of this constant. If the constant has a name,
    * the name is returned enclosed in angular brackets. Otherwise, the string
    * representation of the associated `Valuable` is used.
    *
    * @return A string representing this constant, using its name if available, or
    *         the value's string representation if the name is absent.
    */
  override def toString: String = {
    val string = "$<{x.toString}>"
    s"${maybeName getOrElse string}"
  }

  def simplifyAtomic: em.AutoMatcher[Expression] =
    em.Matcher[Expression, Expression]("NamedConstant:simplifyAtomic")(
      _ =>
        em.Miss[Expression, Expression]("AtomicExpression: simplifyAtomic: NamedConstant", this)
    )
}

/**
  * An abstract representation of a scalar constant in a specific mathematical Valuable,
  * for example, π (pi), 1, 0, but not `e`.
  *
  * This class extends `NamedConstant`, tying the scalar constant to a particular
  * `Valuable` instance and associating it with a specific name. It is designed to
  * represent immutable scalar constants in mathematical expressions, leveraging
  * the properties and operations of the `Valuable`.
  *
  * @param x    the `Valuable` instance representing the value of the scalar constant.
  * @param name the name associated with the scalar constant.
  */
sealed abstract class ScalarConstant(x: Eager, val name: String) extends NamedConstant(x, name) {
  /**
    * Determines if the name is protected, for example, it represents a mathematical symbol
    * for a transcendental value (e.g., pi), or a commonly used root such as √2.
    *
    * This method indicates whether a name associated with an entity is considered
    * protected. The protection status could influence how the name is accessed or
    * utilized by external systems.
    *
    * @return `true` if the name is protected, otherwise `false`
    */
  //  override lazy val protectedName: Boolean = true
}

/**
  * Represents the mathematical constant zero.
  * This object extends the `ScalarConstant` class, providing implementation specific to zero.
  */
case object Zero extends ScalarConstant(WholeNumber.zero, "0") {
  /**
    * Applies the given `ExpressionMonoFunction` to the current context of the `ValueExpression`
    * and attempts to produce an atomic result.
    *
    * @param f the `ExpressionMonoFunction` to be applied. This function determines how the
    *          evaluation will transform the current `ValueExpression` into a potential result.
    * @return an `Option` containing an `ValueExpression` if the evaluation succeeds,
    *         or `None` if the evaluation fails.
    */
  def monadicFunction(f: ExpressionMonoFunction): Option[ValueExpression] = f match {
    case Negate =>
      Some(this)
    case Exp =>
      Some(One)
    case Reciprocal =>
      Some(Infinity)
    case Sine =>
      Some(Zero)
    case Cosine =>
      Some(One)
    case _ =>
      None
  }
}

/**
  * Represents the mathematical constant 1/2 (half).
  *
  * This object is a specific implementation of the `Constant` trait
  * and is used to represent the value of half within mathematical expressions.
  *
  * It provides:
  * - An evaluation method that returns the predefined constant value of half.
  * - A context definition for the constant.
  * - A string representation of the constant.
  */
case object Half extends ScalarConstant(RationalNumber.half, "\u00BD") {
  /**
    * Applies the given `ExpressionMonoFunction` to the current context of the `ValueExpression`
    * and attempts to produce an atomic result.
    *
    * @param f the `ExpressionMonoFunction` to be applied. This function determines how the
    *          evaluation will transform the current `ValueExpression` into a potential result.
    * @return an `Option` containing an `ValueExpression` if the evaluation succeeds,
    *         or `None` if the evaluation fails.
    */
  def monadicFunction(f: ExpressionMonoFunction): Option[ValueExpression] = f match {
    case Negate =>
      Literal.someLiteral(-RationalNumber.half)
    case Reciprocal =>
      Some(Two)
    case _ =>
      None
  }
}

/**
  * Represents the constant numeric value `1`.
  *
  * `One` is a case object that extends `ScalarConstant`, indicating that it is a well-defined,
  * immutable, and atomic mathematical value.
  */
case object One extends ScalarConstant(WholeNumber.one, "1") {
  /**
    * Applies the given `ExpressionMonoFunction` to the current context of the `ValueExpression`
    * and attempts to produce an atomic result.
    *
    * @param f the `ExpressionMonoFunction` to be applied. This function determines how the
    *          evaluation will transform the current `ValueExpression` into a potential result.
    * @return an `Option` containing an `ValueExpression` if the evaluation succeeds,
    *         or `None` if the evaluation fails.
    */
  def monadicFunction(f: ExpressionMonoFunction): Option[ValueExpression] = f match {
    case Negate =>
      Some(MinusOne)
    case Reciprocal =>
      Some(this)
    case Exp =>
      Some(E)
    case Ln =>
      Some(Zero)
    case _ =>
      None
  }
}

/**
  * Represents the constant value -1.
  *
  * MinusOne is a specific instance of the `ScalarConstant` class, which evaluates to
  * the numerical value -1 regardless of the context.
  *
  * This constant can be used in mathematical expressions involving Valuables and
  * supports operations defined in the `Valuable` trait.
  */
case object MinusOne extends ScalarConstant(WholeNumber.minusOne, "-1") {
  /**
    * Applies the given `ExpressionMonoFunction` to the current context of the `ValueExpression`
    * and attempts to produce an atomic result.
    *
    * @param f the `ExpressionMonoFunction` to be applied. This function determines how the
    *          evaluation will transform the current `ValueExpression` into a potential result.
    * @return an `Option` containing an `ValueExpression` if the evaluation succeeds,
    *         or `None` if the evaluation fails.
    */
  def monadicFunction(f: ExpressionMonoFunction): Option[ValueExpression] = f match {
    case Negate =>
      Some(One)
    case Reciprocal =>
      Some(this)
    case _ =>
      None
  }
}

/**
  * Represents the constant number 2 as a case object, extending the `ScalarConstant` class.
  *
  * This object evaluates to the numeric constant `2` within the given context.
  * It can be used in mathematical expressions and operations involving constants.
  */
case object Two extends ScalarConstant(WholeNumber.two, "2") {
  /**
    * Applies the given `ExpressionMonoFunction` to the current context of the `ValueExpression`
    * and attempts to produce an atomic result.
    *
    * @param f the `ExpressionMonoFunction` to be applied. This function determines how the
    *          evaluation will transform the current `ValueExpression` into a potential result.
    * @return an `Option` containing an `ValueExpression` if the evaluation succeeds,
    *         or `None` if the evaluation fails.
    */
  def monadicFunction(f: ExpressionMonoFunction): Option[ValueExpression] = f match {
    case Reciprocal =>
      Some(Half)
    case Negate =>
      Some(ValueExpression(-2))
    case _ =>
      None
  }
}

/**
  * Pi represents the mathematical constant π (pi) exactly.
  */
case object Pi extends ScalarConstant(Angle.pi, "𝛑") {

  override val protectedName: Boolean = true

  /**
    * Applies the given `ExpressionMonoFunction` to the current context of the `ValueExpression`
    * and attempts to produce an atomic result.
    *
    * @param f the `ExpressionMonoFunction` to be applied. This function determines how the
    *          evaluation will transform the current `ValueExpression` into a potential result.
    * @return an `Option` containing an `ValueExpression` if the evaluation succeeds,
    *         or `None` if the evaluation fails.
    */
  def monadicFunction(f: ExpressionMonoFunction): Option[ValueExpression] = f match {
    case Sine =>
      Some(Zero)
    case Cosine =>
      Some(MinusOne)
    case _ =>
      None
  }
}

/**
  * The constant e.
  * Yes, this is an exact number.
  */
case object E extends NamedConstant(NaturalExponential.e, "e") {

  override val protectedName: Boolean = true

  /**
    * Applies the given `ExpressionMonoFunction` to the current context of the `ValueExpression`
    * and attempts to produce an atomic result.
    *
    * @param f the `ExpressionMonoFunction` to be applied. This function determines how the
    *          evaluation will transform the current `ValueExpression` into a potential result.
    * @return an `Option` containing an `ValueExpression` if the evaluation succeeds,
    *         or `None` if the evaluation fails.
    */
  def monadicFunction(f: ExpressionMonoFunction): Option[ValueExpression] = f match {
    case Ln =>
      Some(One)
    case _ =>
      None
  }
}

/**
  * The constant i (viz., the square root of 2)
  * Yes, this is an exact number.
  */
case object I extends NamedConstant(Eager.i, "i") {

  override val protectedName: Boolean = true

  import com.phasmidsoftware.number.algebra.eager.WholeNumber.convIntWholeNumber

  /**
    * Evaluates this `Expression` in the context of `AnyContext` without simplification or factor-based conversion.
    * This allows obtaining a direct evaluation of the `Expression` as a `Field`, if possible.
    * NOTE: no simplification or factor-based conversion occurs here.
    *
    * @return an `Option[Field]` containing the evaluated `Field` if evaluation is successful, or `None` otherwise.
    */
  override lazy val evaluateAsIs: Option[InversePower] = Some(Eager.imaginary(1))

  lazy val asComplex: Option[Complex] = evaluateAsIs flatMap (_.asComplex)

  /**
    * Provides an approximation of the current value as a complex number.
    *
    * @param force a Boolean flag indicating whether to force the computation, even
    *              if it would otherwise be skipped (default is false).
    *
    * @return an Option containing the approximated complex value as an Eager, or None if
    *         the approximation cannot be performed.
    */
  override def approximationComplex(force: Boolean = false): Option[Eager] =
    asComplex

  /**
    * Applies the given `ExpressionMonoFunction` to the current context of the `ValueExpression`
    * and attempts to produce an atomic result.
    *
    * @param f the `ExpressionMonoFunction` to be applied. This function determines how the
    *          evaluation will transform the current `ValueExpression` into a potential result.
    * @return an `Option` containing an `ValueExpression` if the evaluation succeeds,
    *         or `None` if the evaluation fails.
    */
  def monadicFunction(f: ExpressionMonoFunction): Option[ValueExpression] = f match {
    case _ =>
      None
  }
}

/**
  * Represents an infinite value in the Valuable of expressions.
  *
  * The `Infinity` object is a special case of `NamedConstant` with a value of positive infinity.
  * It is immutable and serves as a singleton instance to represent the mathematical concept of infinity
  * in calculations or expressions. It overrides certain behaviors of `ValueExpression` to handle
  * operations specific to infinity.
  */
case object Infinity extends NamedConstant(Eager(Rational.infinity), "∞") {

  override val protectedName: Boolean = true

  /**
    * Applies the given `ExpressionMonoFunction` to the current context of the `ValueExpression`
    * and attempts to produce an atomic result.
    *
    * @param f the `ExpressionMonoFunction` to be applied. This function determines how the
    *          evaluation will transform the current `ValueExpression` into a potential result.
    * @return an `Option` containing an `ValueExpression` if the evaluation succeeds,
    *         or `None` if the evaluation fails.
    */
  def monadicFunction(f: ExpressionMonoFunction): Option[ValueExpression] = f match {
    case Reciprocal =>
      Some(Zero)
    case Exp =>
      Some(Infinity)
    case _ =>
      None
  }
}
