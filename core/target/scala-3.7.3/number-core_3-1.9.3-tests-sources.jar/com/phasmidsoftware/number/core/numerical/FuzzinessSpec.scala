package com.phasmidsoftware.number.core.numerical

import com.phasmidsoftware.number.core.inner.*
import com.phasmidsoftware.number.core.numerical.Constants.sG
import com.phasmidsoftware.number.core.numerical.Fuzziness.{createFuzz, monadicFuzziness}
import com.phasmidsoftware.number.core.numerical.WithFuzziness.{Asterisk, Ellipsis}
import com.phasmidsoftware.number.core.parse.NumberParser
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should

import scala.util.Try

class FuzzinessSpec extends AnyFlatSpec with should.Matchers {

  private val p = NumberParser
  val sAlpha = "0.0072973525693(11)"

  behavior of "generalNumber"
  it should "parse 1." in {
    val z = p.parseAll(p.generalNumber, "1.")
    z should matchPattern { case p.Success(p.RealNumber(false, "1", None, None), _) => }
  }
  it should "parse 1.0" in {
    val z = p.parseAll(p.generalNumber, "1.0")
    z should matchPattern { case p.Success(p.RealNumber(false, "1", Some("0"), None), _) => }
  }
  it should "parse 1.00" in {
    val z = p.parseAll(p.generalNumber, "1.00")
    z should matchPattern { case p.Success(p.RealNumber(false, "1", Some("00"), None), _) => }
  }
  it should "parse 1.000 as fuzzy" in {
    val z = p.parseAll(p.generalNumber, "1.000")
    z should matchPattern { case p.Success(p.RealNumber(false, "1", Some("000"), None), _) => }
  }
  it should "parse G as fuzzy" in {
    val z = p.parseAll(p.generalNumber, sG)
    z.get shouldBe p.NumberWithFuzziness(p.RealNumber(sign = false, "6", Some("67430"), None), Some("(15)"), Some("-11"))
  }

  behavior of "maybeNumber"
  it should "" in {
    val z = p.parseAll(p.maybeNumber, sG)
    z.get.get.isExact shouldBe false
    z.get.get.fuzz.get shouldBe AbsoluteFuzz(1.5E-15, Gaussian)
  }

  behavior of "number"
  it should "" in {
    val z: p.ParseResult[Number] = p.parseAll(p.number, sG)
    z.get.isExact shouldBe false
    z.get.fuzz.get shouldBe AbsoluteFuzz(1.5E-15, Gaussian)
  }

  behavior of "StringParser"
  it should "" in {
    val x = NumberParser
    val q: Try[Number] = x.parseNumber(sG)
    q.get.isExact shouldBe false
    q.get.fuzz.get shouldBe AbsoluteFuzz(1.5E-15, Gaussian)
  }

  behavior of "fuzz"
  it should "parse *" in {
    val z = p.parseAll(p.fuzz, Asterisk)
    z should matchPattern { case p.Success(Some(Asterisk), _) => }
  }
  it should "parse ..." in {
    val z = p.parseAll(p.fuzz, Ellipsis)
    z should matchPattern { case p.Success(Some(Ellipsis), _) => }
  }
  it should "parse (5)" in {
    val z = p.parseAll(p.fuzz, "(5)")
    z should matchPattern { case p.Success(Some("(5)"), _) => }
  }
  it should "parse (15)" in {
    val z = p.parseAll(p.fuzz, "(15)")
    z should matchPattern { case p.Success(Some("(15)"), _) => }
  }
  it should "fail to parse (315)" in {
    // NOTE too many fuzz digits
    val z = p.parseAll(p.fuzz, "(315)")
    z should matchPattern { case p.Failure(_, _) => }
  }
  it should "fail to parse .." in {
    val z = p.parseAll(p.fuzz, "..")
    z should matchPattern { case p.Failure(_, _) => }
  }

  behavior of "FuzzOps"
  it should "understand ..." in {
    import Number.FuzzOps
    val x = 3.1415927 ~ 12
    x.isExact shouldBe false
    x.toString shouldBe "FuzzyNumber(Left(Left(Some(3.1415927))),,Some(AbsoluteFuzz(1.2E-6,Gaussian)))"
    x.render shouldBe "3.1415927(12)"
  }

  behavior of "exponent"
  it should "parse E-11" in {
    val z = p.parseAll(p.exponent, "E-11")
    z should matchPattern { case p.Success(_, _) => }
    z.get shouldBe "-11"
  }

  behavior of "numberWithFuzziness"
  it should "parse 1.0*" in {
    val z = p.parseAll(p.numberWithFuzziness, s"1.0$Asterisk")
    z should matchPattern { case p.Success(_, _) => }
    z.get shouldBe p.NumberWithFuzziness(p.RealNumber(sign = false, "1", Some("0"), None), Some(Asterisk), None)
  }
  it should "parse 1.0..." in {
    val z: p.ParseResult[p.NumberWithFuzziness] = p.parseAll(p.numberWithFuzziness, s"1.0$Ellipsis")
    z should matchPattern { case p.Success(_, _) => }
    z.get shouldBe p.NumberWithFuzziness(p.RealNumber(sign = false, "1", Some("0"), None), Some(Ellipsis), None)
  }
  it should "parse G" in {
    val z: p.ParseResult[p.NumberWithFuzziness] = p.parseAll(p.numberWithFuzziness, sG)
    z should matchPattern { case p.Success(_, _) => }
    z.get shouldBe p.NumberWithFuzziness(p.RealNumber(sign = false, "6", Some("67430"), None), Some("(15)"), Some("-11"))
  }
  it should "parse alpha" in {
    val z: p.ParseResult[p.NumberWithFuzziness] = p.parseAll(p.numberWithFuzziness, sAlpha)
    z should matchPattern { case p.Success(_, _) => }
    z.get shouldBe p.NumberWithFuzziness(p.RealNumber(sign = false, "0", Some("0072973525693"), None), Some("(11)"), None)
  }

  behavior of "Fuzz.toString"
  it should "work for 1/0.5/Box" in {
    val target = AbsoluteFuzz(0.5, Box)
    target.getQualifiedString(1) shouldBe(true, "1.0[5]")
  }
  it should "work for 1/0.005/Box" in {
    val target = AbsoluteFuzz(0.005, Box)
    target.getQualifiedString(1) shouldBe(true, "1.000[5]")
  }
  it should "work for 1/0.5/Gaussian" in {
    val target = AbsoluteFuzz(0.5, Gaussian)
    target.getQualifiedString(1) shouldBe(true, "1.0(5)")
  }
  it should "work for 1/0.005/Gaussian" in {
    val target = AbsoluteFuzz(0.005, Gaussian)
    target.getQualifiedString(1) shouldBe(true, "1.000(5)")
  }
  it should "work for Planck" in {
    val target = AbsoluteFuzz(5E-41, Gaussian)
    target.getQualifiedString(6.62607015E-34) shouldBe(true, "6.6260701(5)E-34")
  }
  it should "work for Avagadro" in {
    val target = AbsoluteFuzz(5E16, Gaussian)
    target.getQualifiedString(6.02214076E23) shouldBe(true, "6.0221407(5)E+23")
  }
  it should "work for 3.1415927*" in {
    val xy: Try[Number] = Number.parse("3.1415927*")
    xy.get.isExact shouldBe false
    val z: Number = xy.get
    val q: Option[String] = z.fuzz.map(f => f.getQualifiedString(3.1415927)._2)
    q should matchPattern { case Some("3.14159270[5]") => }
  }
  it should "work for 3.1416" in {
    val target = Number("3.1416")
    target.toString shouldBe "3.1416"
  }

  behavior of "parse"
  it should "work for 2.*" in {
    val xy = Number.parse("2.*")
    xy.get.fuzz should matchPattern { case Some(AbsoluteFuzz(0.5, Box)) => }
    xy.get.fuzz.get.normalizeShape should matchPattern { case AbsoluteFuzz(0.2886751345948129, Gaussian) => }
  }

  behavior of "createFuzz"
  it should "work for None" in {
    createFuzz(None) shouldBe None
  }
  it should "work for 0" in {
    createFuzz(Some(0)) shouldBe Some(RelativeFuzz(1.6E-16, Box))
  }
  it should "work for 1" in {
    createFuzz(Some(1)) shouldBe Some(RelativeFuzz(3.2E-16, Box))
  }
  it should "work for 5" in {
    createFuzz(Some(5)) shouldBe Some(RelativeFuzz(5.12E-15, Box))
  }

  behavior of "render"
  private val z = implicitly[HasValue[Double]]
  it should "render Pi" in {
    z.render(3.1415927) shouldBe "3.141592700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
  }
  it should "render Planck" in {
    z.render(6.62607015E-34) shouldBe "6.62607015000000000000E-34"
  }
  it should "render Avagadro" in {
    z.render(6.02214076E23) shouldBe "6.02214076000000000000E+23"
  }

  behavior of "Box.wiggle"
  it should "be likely for 1.251*" in {
    val xy = Number.parse("1.251*")
    xy.isSuccess shouldBe true
    val x: Number = xy.get
    val z: Option[Fuzziness[Double]] = x.fuzz
    z.isDefined shouldBe true
    val q: Fuzziness[Double] = z.get
    q.shape should matchPattern { case Box => }
    q.shape.wiggle(0.0005) shouldBe 0.00025
    // NOTE that the probability is ignored for a box
    q.shape.wiggle(0.0005, 0.1) shouldBe 0.00025
    q.shape.wiggle(0.0005, 0.9) shouldBe 0.00025
  }

  behavior of "Fuzziness.wiggle"
  it should "be likely for 1.251* (box)" in {
    val xy = Number.parse("1.251*")
    xy.isSuccess shouldBe true
    val x: Number = xy.get
    val z: Option[Fuzziness[Double]] = x.fuzz
    z.isEmpty shouldBe false
    val q: Fuzziness[Double] = z.get
    q.wiggle() shouldBe 0.00025
    // NOTE that the probability is ignored for a box
    q.wiggle(0.1) shouldBe 0.00025
    q.wiggle(0.9) shouldBe 0.00025
  }

  behavior of "Box.wiggle"
  it should "be likely for 5.0040" in {
    val xy: Option[Number] = for {
      a <- Number.parse("1.251").toOption
      b <- Number.parse("4.00*").toOption
      x <- (a doMultiply  b).asNumber
    } yield x
    xy.isDefined shouldBe true
    val x: Number = xy.get
    val z: Option[Fuzziness[Double]] = x.fuzz
    z.isDefined shouldBe true
    val q: Fuzziness[Double] = z.get
    q should matchPattern { case RelativeFuzz(_, _) => }
    q.shape should matchPattern { case Box => }
    q.style shouldBe true
    val h: Option[Fuzziness[Double]] = q.normalize(x.toNominalDouble.getOrElse(Double.NaN), relative = true)
    val r = h.get.asInstanceOf[RelativeFuzz[Double]].tolerance
    r shouldBe 0.00125 // 0.0016496802557953638 +- 0.0000000001
    h.get.shape.wiggle(r, 0.0) shouldBe Double.PositiveInfinity
    h.get.shape.wiggle(r, 0.9) shouldBe 6.25E-4
    h.get.shape.wiggle(r, 1) shouldBe 0
  }
  behavior of "Trapezoid.wiggle"
  it should "be independent of p in flat-top region" in {
    val t = Trapezoid(1.0, 2.0)
    // threshold = a/b = 0.5; flat-top when confidence > threshold
    t.wiggle(0, 0.0) shouldBe Double.PositiveInfinity
    t.wiggle(0, 0.6) shouldBe 1.0 // flat-top: b-a = 1.0
    t.wiggle(0, 0.9) shouldBe 1.0 // flat-top: b-a = 1.0
    t.wiggle(0, 1.0) shouldBe 0.0
  }
  it should "be in ramp region for p > threshold" in {
    val t = Trapezoid(1.0, 2.0)
    // threshold = a/b = 0.5; ramp region when confidence < threshold
    t.wiggle(0, 0.2) shouldBe (3.0 - 2 * math.sqrt(1.0 * 2.0 * 0.2)) +- 1E-10
    t.wiggle(0, 0.4) shouldBe (3.0 - 2 * math.sqrt(1.0 * 2.0 * 0.4)) +- 1E-10
  }
  it should "be continuous at the boundary" in {
    val t = Trapezoid(1.0, 2.0)
    val threshold = (2.0 - 1.0) / 2.0 // = 0.5
    t.wiggle(0, threshold) shouldBe (3.0 - math.sqrt(2 * 1 * (1 + 2 * 0.5))) +- 1E-10
  }
  it should "work for the triangle case (a==b)" in {
    val t = Trapezoid(2.0, 2.0)
    t.wiggle(0) shouldBe 1.7478898783585204 +- 1E-10
    t.wiggle(0, 0.75) shouldBe (4.0 - 2 * math.sqrt(4.0 * 0.75)) +- 1E-10 // ≈ 0.536
    t.wiggle(0, 0.0) shouldBe Double.PositiveInfinity
    t.wiggle(0, 1.0) shouldBe 0.0
  }

  behavior of "Trapezoid.probability"
  it should "work in flat-top region" in {
    val t = Trapezoid(1.0, 2.0)
    t.probability(0, 0.0) shouldBe 0.0
    t.probability(0, 0.5) shouldBe 0.25 // x/b = 0.5/2
    t.probability(0, 1.0) shouldBe 0.5 // (b-a)/b = threshold
  }
  it should "work in ramp region" in {
    val t = Trapezoid(1.0, 2.0)
    t.probability(0, 2.0) shouldBe 0.875 +- 1E-10
    t.probability(0, 3.0) shouldBe 1.0
  }
  it should "be consistent with wiggle (round-trip)--in ramp region only" in {
    val t = Trapezoid(1.0, 2.0)
    // threshold = a/b = 0.5; ramp region when confidence < threshold
    for (confidence <- Seq(0.1, 0.2, 0.3, 0.4)) {
      t.probability(0, t.wiggle(0, confidence)) shouldBe (1 - confidence) +- 1E-10
    }
  }

  behavior of "Trapezoid.sigma"
  it should "match sum of Box variances" in {
    val t = Trapezoid(1.0, 2.0)
    t.sigma shouldBe math.sqrt((1.0 + 4.0) / 3.0) +- 1E-10
  }
  it should "degenerate correctly to Box case" in {
    // Trapezoid(0, b) should have same sigma as Box(b)
    val t = Trapezoid(0.0, 2.0) // NOTE: requires relaxing require(a<=b) to require(a>=0)
    t.sigma shouldBe Box.toGaussianAbsolute(2.0) +- 1E-10
  }

  behavior of "Box-like trapezoid"
  it should "behave like Box(b) when a << b" in {
    val t = Trapezoid(0.1, 10.0)
    // Well within flat-top region: probability should match Box(b) closely
    // Box.probability(l, x) = x/l; Trapezoid.probability in flat-top = x/b
    t.probability(0, 5.0) shouldBe Box.probability(10.0, 5.0) +- 0.01
    t.probability(0, 8.0) shouldBe Box.probability(10.0, 8.0) +- 0.01
    // In flat-top, wiggle is independent of confidence, like Box
    t.wiggle(0, 0.5) shouldBe 9.9 +- 0.01 // b-a, close to b=10
    t.wiggle(0, 0.8) shouldBe 9.9 +- 0.01 // same flat-top value
    // Near the edge, diverges from Box
    t.probability(0, 10.0) shouldBe Box.probability(10.0, 10.0) +- 0.1
  }

  behavior of "AbsoluteFuzz convolution Box*Box"
  it should "produce a Trapezoid" in {
    val f1 = AbsoluteFuzz(1.0, Box)
    val f2 = AbsoluteFuzz(2.0, Box)
    val result = f1 * (f2, true)
    result should matchPattern { case AbsoluteFuzz(_, Trapezoid(1.0, 2.0)) => }
    result.asInstanceOf[AbsoluteFuzz[Double]].magnitude shouldBe 3.0
  }
  it should "normalizeShape to Gaussian" in {
    val f1 = AbsoluteFuzz(1.0, Box)
    val f2 = AbsoluteFuzz(2.0, Box)
    val result = (f1 * (f2, true)).normalizeShape
    result should matchPattern { case AbsoluteFuzz(_, Gaussian) => }
    result.asInstanceOf[AbsoluteFuzz[Double]].magnitude shouldBe
      math.sqrt(5.0 / 3.0) +- 1E-10
  }
  behavior of "RelativeFuzz convolution Box*Box"
  it should "produce a Trapezoid" in {
    val f1 = RelativeFuzz[Double](0.01, Box)
    val f2 = RelativeFuzz[Double](0.02, Box)
    val result = f1 * (f2, true)
    result should matchPattern { case RelativeFuzz(_, Trapezoid(0.01, 0.02)) => }
    result.asInstanceOf[RelativeFuzz[Double]].tolerance shouldBe 0.03 +- 1E-10
  }
  it should "normalizeShape to Gaussian" in {
    val f1 = RelativeFuzz[Double](0.01, Box)
    val f2 = RelativeFuzz[Double](0.02, Box)
    val result = (f1 * (f2, true)).normalizeShape
    result should matchPattern { case RelativeFuzz(_, Gaussian) => }
    result.asInstanceOf[RelativeFuzz[Double]].tolerance shouldBe
      math.sqrt((0.01 * 0.01 + 0.02 * 0.02) / 3.0) +- 1E-10
  }
  it should "be symmetric" in {
    val f1 = RelativeFuzz[Double](0.01, Box)
    val f2 = RelativeFuzz[Double](0.02, Box)
    (f1 * (f2, true)) shouldBe (f2 * (f1, true))
  }
  it should "combine two Boxes as a Trapezoid" in {
    import com.phasmidsoftware.number.core.numerical.Number

    // proton-electron mass ratio
    val ratio = Number(1836.15267343)
    val ratioEstimate = Number(1836.1526734)

    // This is supposed to generate a fuzzy number with Trapezoid-type fuzziness.
    val ratioError = ratio `doSubtract` ratioEstimate
    println(ratioError)
    ratioError.isProbablyZero(0.3) shouldBe true
  }

  behavior of "RelativeFuzz.wiggle with Trapezoid"
  it should "work in flat-top region" in {
    val f = RelativeFuzz[Double](0.03, Trapezoid(0.01, 0.02))
    // threshold = a/b = 0.01/0.02 = 0.5; flat-top when confidence > threshold
    f.wiggle(0.6) shouldBe 0.01 // b-a, independent of confidence
    f.wiggle(0.9) shouldBe 0.01
  }
  it should "work in ramp region" in {
    val f = RelativeFuzz[Double](0.03, Trapezoid(0.01, 0.02))
    // ramp region when confidence < a/b = 0.5
    f.wiggle(0.3) shouldBe
      (0.03 - 2 * math.sqrt(0.01 * 0.02 * 0.3)) +- 1E-10
  }
  it should "be consistent with probability (round-trip)" in {
    val t = Trapezoid(0.01, 0.02)
    val f = RelativeFuzz[Double](0.03, t)
    // threshold = a/b = 0.5; ramp region when confidence < threshold
    for (confidence <- Seq(0.1, 0.2, 0.3, 0.4)) {
      val w = f.wiggle(confidence)
      t.probability(0, implicitly[HasValue[Double]].toDouble(w)) shouldBe (1 - confidence) +- 1E-10
    }
  }

  behavior of "RelativeFuzz convolution Trapezoid*Gaussian"
  it should "normalize Trapezoid to Gaussian before convolving" in {
    val t = Trapezoid(0.01, 0.02)
    val f1 = RelativeFuzz[Double](0.03, t)
    val f2 = RelativeFuzz[Double](0.05, Gaussian)
    val result = f1.normalizeShape * (f2, true)
    result should matchPattern { case RelativeFuzz(_, Gaussian) => }
    result.asInstanceOf[RelativeFuzz[Double]].tolerance shouldBe
      Gaussian.convolutionProduct(t.sigma, 0.05, independent = true) +- 1E-10
  }

  behavior of "Gaussian.wiggle"
  it should "be likely for 5.0040" in {
    val xy: Option[Number] = for (a <- Number.parse("1.250(2)").toOption; b <- Number.parse("4.00*").toOption; x <- (a doMultiply b).asNumber) yield x
    xy.isDefined shouldBe true
    val x: Number = xy.get
    val z: Option[Fuzziness[Double]] = for (y <- x.fuzz; w <- x.toNominalDouble; v <- y.normalize(w, relative = true)) yield v
    //    x.fuzz flatMap (_.normalize(x.toDouble, true))
    z.isDefined shouldBe true
    val q: Fuzziness[Double] = z.get
    q should matchPattern { case RelativeFuzz(_, _) => }
    q.shape should matchPattern { case Gaussian => }
    q.style shouldBe true
    val r = q.asInstanceOf[RelativeFuzz[Double]].tolerance
    r shouldBe 0.0020580412706533817 +- 0.0000000001
    q.shape.wiggle(r, 0.0) shouldBe Double.PositiveInfinity
    q.shape.wiggle(r, 0.1) shouldBe (r * 1.1630871536766743 / Gaussian.sigma) +- 0.00001
    q.shape.wiggle(r, 0.2) shouldBe (r * 0.9061938024368233 / Gaussian.sigma) +- 0.00001
    q.shape.wiggle(r, 0.3) shouldBe (r * 0.7328690779592166 / Gaussian.sigma) +- 0.00001
    q.shape.wiggle(r, 0.4) shouldBe (r * 0.5951160814499948 / Gaussian.sigma) +- 0.00001
    q.shape.wiggle(r, 0.5) shouldBe (r * 0.47693627620446977 / Gaussian.sigma) +- 0.00001
    q.shape.wiggle(r, 0.5) shouldBe 0.0013881277425362257 +- 0.000001
    q.shape.wiggle(r, 0.6) shouldBe (r * 0.37080715859355795 / Gaussian.sigma) +- 0.00001
    q.shape.wiggle(r, 0.7) shouldBe (r * 0.27246271472675443 / Gaussian.sigma) +- 0.00001
    q.shape.wiggle(r, 0.8) shouldBe (r * 0.1791434546212916 / Gaussian.sigma) +- 0.00001
    q.shape.wiggle(r, 0.9) shouldBe (r * 0.08885599049425764 / Gaussian.sigma) +- 0.00001
    q.shape.wiggle(r, 1) shouldBe 0
  }
  it should "define the following ranges" in {
    val x = Number.zero
    x.addFuzz(AbsoluteFuzz(1, Gaussian)).fuzz.get.wiggle(0.5) shouldBe 0.6744897501960815
    x.addFuzz(AbsoluteFuzz(1, Gaussian)).fuzz.get.wiggle(0.75) shouldBe 0.3186393639643751
    x.addFuzz(AbsoluteFuzz(1, Gaussian)).fuzz.get.wiggle(0.25) shouldBe 1.1503493803760079
    x.addFuzz(AbsoluteFuzz(1, Gaussian)).fuzz.get.wiggle(0.1) shouldBe 1.6448536269514729
    x.addFuzz(AbsoluteFuzz(1, Gaussian)).fuzz.get.wiggle(0.01) shouldBe 2.5758293035489004
    x.addFuzz(AbsoluteFuzz(1, Gaussian)).fuzz.get.wiggle(0.001) shouldBe 3.2905267314918945
    x.addFuzz(AbsoluteFuzz(1, Gaussian)).fuzz.get.wiggle(0.0001) shouldBe 3.8905918864131213
  }
  it should "be likely." in {
    val x = Number.zero
    x.addFuzz(AbsoluteFuzz(1, Gaussian)).fuzz.get.wiggle(1 - 0.6827) shouldBe 1.0000217133229987
    x.addFuzz(AbsoluteFuzz(1, Gaussian)).fuzz.get.wiggle(1 - 0.95) shouldBe 1.9599639845400538
    x.addFuzz(AbsoluteFuzz(1, Gaussian)).fuzz.get.wiggle(1 - 0.997) shouldBe 2.9677379253417824
  }
  it should "pass the sanity check for converting from Box to Gaussian" in {
    val x = Number.zero
    val y = x.addFuzz(AbsoluteFuzz(1, Box))
    y.fuzz.get.wiggle() shouldBe 0.5
    val fuzz = y.fuzz
    val z = fuzz.map(f => f.normalizeShape)
    z.get shouldBe AbsoluteFuzz[Double](0.5773502691896258, Gaussian)
    z.get.wiggle() shouldBe 0.5777208291983995
  }

  behavior of "probability"
  it should "work for a box" in {
    val fuzz = Number.zero.addFuzz(AbsoluteFuzz(1, Box)).fuzz.get
    fuzz.probability(1.0, 0.0) shouldBe 0.0
    fuzz.probability(1.0, 0.25) shouldBe 0.25
    fuzz.probability(1.0, 0.5) shouldBe 0.5
    fuzz.probability(1.0, 1.0) shouldBe 1.0
  }
  it should "work for a Gaussian" in {
    val fuzz: Fuzziness[Double] = Number.zero.addFuzz(AbsoluteFuzz(1, Gaussian)).fuzz.get
    fuzz.probability(1.0, 0.6744897501960815) shouldBe 0.5 +- 1E-6
    fuzz.probability(1.0, 0.3186393639643751) shouldBe 0.25 +- 1E-6
    fuzz.probability(1.0, 1.1503493803760079) shouldBe 0.75 +- 1E-6
    fuzz.probability(1.0, 1.6448536269514729) shouldBe 0.9 +- 1E-6
    fuzz.probability(1.0, 2.5758293035489004) shouldBe 0.99 +- 1E-6
    fuzz.probability(1.0, 3.2905267314918945) shouldBe 0.999 +- 1E-6
    fuzz.probability(1.0, 3.8905918864131213) shouldBe 0.9999 +- 1E-6
  }

  behavior of "map"
  it should "work" in {
    val fuzz = RelativeFuzz(1E-15, Box)
    // TODO do this through pattern matching
    val n: FuzzyNumber = FuzzyNumber(Value.fromInt(1), PureNumber, None).addFuzz(fuzz).asInstanceOf[FuzzyNumber]
    val op = MonadicOperationExp
    val r: Option[Value] = Operations.doTransformValueMonadic(n.nominalValue)(op.functions)
    r.isDefined shouldBe true
    val q = n.make(r.get, PureNumber)
    val x = q.toNominalDouble
    val v = x.get
    val z: Option[Fuzziness[Double]] = Fuzziness.map[Double, Double, Double](1, v, relative = true, op.relativeFuzz, Some(fuzz))
    val w = z.toString
    w shouldBe "Some(RelativeFuzz(1.0E-15,Box))"
  }

  behavior of "power"
  it should "work for e∧x" in {
    //    pending // WI14 (Issue #197)
    val two = Number("2.00[2]")
    val nominalValueOfTwo = 2
    val relativeErrorOfTwo = 0.01
    val z: Number = Number.exp(two).scale(PureNumber)
    z.fuzz.get.asInstanceOf[RelativeFuzz[Double]].tolerance shouldBe (nominalValueOfTwo * relativeErrorOfTwo) +- 1.0E-10
  }

  behavior of "fuzz"
  it should "work" in {
    val op = MonadicOperationInvert
    val t = -0.009003823032986082 // the input to the inversion.
    val x = -111.06393321330684 // the output from the inversion.
    val fuzz = Some(RelativeFuzz(1.0846958231396446E-9, Gaussian))
    monadicFuzziness(op, t, x, fuzz)
  }
}