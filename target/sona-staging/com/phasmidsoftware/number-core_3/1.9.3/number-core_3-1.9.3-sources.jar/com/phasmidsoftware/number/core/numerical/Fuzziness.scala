/*
 * Copyright (c) 2023. Phasmid Software
 */

package com.phasmidsoftware.number.core.numerical

import com.phasmidsoftware.number.core.inner.{MonadicOperation, Percent}
import com.phasmidsoftware.number.core.misc.Variance.{convolution, rootSumSquares}
import com.phasmidsoftware.number.core.numerical.Fuzziness.{oneSigma, toDecimalPower, zipStrings}
import com.phasmidsoftware.number.core.numerical.HasValue.HasValueDouble$
import org.apache.commons.math3.special.Erf.{erf, erfInv}

import scala.math.Numeric.DoubleIsFractional
import scala.util.Try
import scala.util.matching.Regex

/**
  * This trait models the behavior of fuzziness.
  *
  * See also related trait Fuzzy[X].
  *
  * @tparam T the underlying type of the fuzziness. Usually Double for fuzzy numerics.
  */
sealed trait Fuzziness[T] {
  /**
    * One of two shapes for the probability density function:
    * Gaussian (normal distribution);
    * Box (uniform distribution).
    */
  val shape: Shape

  /**
    * True if this is relative Fuzziness as opposed to absolute fuzz.
    */
  val style: Boolean

  /**
    * Transform this Fuzziness[T] according to func.
    * Typically, func will be the relative fuzz function arising from a monadic operation.
    *
    * @param func the function to apply to this Fuzziness[T].
    * @return an (optional) transformed version of Fuzziness[T].
    */
  def transform[U: HasValue, V: HasValue](func: T => V)(t: T): Fuzziness[U]

  /**
    * Perform a convolution on this Fuzziness[T] with the given addend.
    * There are two different Fuzziness[T] shapes, and they clearly have different effects.
    * When the shapes are absolute, this operation is suitable for the addition of Numbers.
    * When the shapes are relative, this operation is suitable for multiplication of Numbers.
    *
    * Whether or not this is a true convolution, I'm not sure.
    * But, it is an operation to combine two probability density functions and, as such, f * g = g * f.
    *
    * @param convolute   the convolute, which must have the same shape as this.
    * @param independent true if the fuzz distributions are independent.
    * @return the convolution of this and the convolute.
    */
  def *(convolute: Fuzziness[T], independent: Boolean): Fuzziness[T]

  /**
    * Method to possibly change the style of this `Fuzziness[T]`.
    *
    * @param t        the magnitude of the relevant `Number`.
    * @param relative if true then change to Relative (if Absolute).
    * @return the (optional) `Fuzziness` as a Relative or Absolute `Fuzziness`, according to relative.
    */
  def normalize(t: T, relative: Boolean): Option[Fuzziness[T]]

  /**
    * Method to convert this Fuzziness[T] into a Fuzziness[T] with Gaussian shape.
    *
    * @return the equivalent Fuzziness[T] with Gaussian shape.
    */
  def normalizeShape: Fuzziness[T]

  /**
    * Method to yield a String to render the given T value.
    * The result is qualified by a Boolean indicating if the value is embedded in the result.
    *
    * @param t               a T value.
    * @param forceScientific if true, always use scientific notation regardless of value magnitude.
    * @return a tuple of a Boolean and a String that is the textual rendering of t with this Fuzziness applied.
    */
  def getQualifiedString(t: T, forceScientific: Boolean = false): (Boolean, String)

  /**
    * A variation on toString where we render this Fuzziness as a percentage.
    *
    * @return a String which ends with the '%' character (provided that this Fuzziness is relative).
    */
  def asPercentage: String

  /**
    * Determine the half-width δ such that the cumulative probability P(-δ, δ) = 1 - confidence.
    * In other words, get the wiggle room: the range within which a random point will fall
    * with probability (1 - confidence).
    * NOTE that the greater the value of confidence, the smaller the resulting wiggle room.
    *
    * @param confidence the tail probability: the probability of a random point falling
    *                   *outside* the range [-δ, δ]. Typical value: oneSigma.
    * @return δ, the half-width of the symmetric interval around the mean.
    */
  def wiggle(confidence: Double = oneSigma): T

  /**
    * Computes the probability that random points will be found with the range `-x` to `+x` where `l` is a measure of the magnitude of this Fuzziness.
    * TODO change the types of l and x to be T
    *
    * @param l the size or scale of the probability density function (e.g., standard deviation for a Gaussian distribution).
    * @param x the specific point that bounds the region we're interested in.
    * @return the calculated probability density at the given point.
    */
  def probability(l: Double, x: Double): Double =
    shape.probability(l, x)

  /**
    * Creates a Fuzziness instance with an absolute fuzz value of zero,
    * using a Gaussian distribution. This can be used to represent the
    * absence of fuzziness or uncertainty in a value.
    *
    * @return a Fuzziness[U] instance with zero fuzziness and Gaussian shape.
    */
  def noFuzz[U >: T : HasValue]: Fuzziness[U] =
    AbsoluteFuzz(implicitly[HasValue[U]].fromDouble(0), Gaussian)

  /**
    * Creates a fuzziness value using the given input magnitude and applies a Gaussian distribution.
    * This is intended for the situation where we evaluate a series of terms until the remaining terms are
    * smaller than some threshold (the magnitude).
    * CONSIDER in general, we may want to apply a safety factor of 2 or 3 here.
    *
    * @param u the magnitude of the input value used to compute fuzziness.
    * @return a Fuzziness[Double] instance representing the absolute fuzziness with Gaussian distribution.
    */
  def uncertainty[U >: T : HasValue](u: U): Fuzziness[U] =
    AbsoluteFuzz(u, Gaussian)
}

/**
  * Relative fuzziness.
  *
  * @param tolerance the error bound.
  * @param shape     the shape (Uniform, Gaussian, etc.)
  * @tparam T the underlying type of the fuzziness. Usually Double for fuzzy numerics [must have HasValue].
  */
case class RelativeFuzz[T: HasValue](tolerance: Double, shape: Shape) extends Fuzziness[T] {

  private val tv: HasValue[T] = implicitly[HasValue[T]]

  /**
    * Transform this Fuzziness[T] according to func.
    * Typically, func will be the derivative of the relevant Number function.
    *
    * @param func the function to apply to this Fuzziness[T].
    * @param t    the value of t (i.e., the input value) which will be passed into func.
    * @tparam U the underlying type of the result.
    * @tparam V the type of the quotient of T/U.
    * @return a transformed version of Fuzziness[U].
    */
  def transform[U: HasValue, V: HasValue](func: T => V)(t: T): Fuzziness[U] = {
    val duByDt: V = func(t)
    val dU: U = implicitly[HasValue[U]].multiply(implicitly[HasValue[T]].fromDouble(tolerance), duByDt)
    RelativeFuzz[U](implicitly[HasValue[U]].toDouble(dU), shape)
  }

  /**
    * This method takes a value of T on which to base a relative fuzz value.
    *
    * @param t the nominal value of the fuzzy number.
    * @return an optional RelativeFuzz[T]
    */
  def absolute(t: T): Option[AbsoluteFuzz[T]] = {
    // CONSIDER using multiply, scale, etc.
    Try(AbsoluteFuzz(tv.normalize(tv.times(tv.fromDouble(tolerance), t)), shape)).toOption
  }

  /**
    * Return either an AbsoluteFuzz equivalent or this, according to relative.
    *
    * @param t        the magnitude of the relevant Number.
    * @param relative if true then convert to RelativeFuzz otherwise wrap this in Some().
    * @return the (optional) Fuzziness as a Relative or Absolute Fuzziness, according to relative.
    */
  def normalize(t: T, relative: Boolean): Option[Fuzziness[T]] =
    if (relative)
      Some(this)
    else
      absolute(t) match {
        case Some(AbsoluteFuzz(mag, _)) if {
          val magDouble = implicitly[HasValue[T]].toDouble(mag)
          !magDouble.isInfinite && !magDouble.isNaN
        } =>
          absolute(t)
        case _ =>
          Some(this)
      }
  /**
    * Perform a convolution on this Fuzziness[T] with the given addend.
    * This operation is suitable for multiplication of Numbers.
    *
    * @param convolute   the convolute, which must have the same shape as this.
    * @param independent true if the distributions are independent.
    * @return the convolution of this and the convolute.
    */
  def *(convolute: Fuzziness[T], independent: Boolean): Fuzziness[T] = convolute match {
    case RelativeFuzz(t, Box) if this.shape == Box =>
      // Box ⊗ Box → Trapezoid, subject to the three-tier rules.
      Fuzziness.applyRules(tolerance, t) {
        val (a, b) = (math.min(tolerance, t), math.max(tolerance, t))
        RelativeFuzz(a + b, Trapezoid(a, b))
      } match {
        case Left(m) => RelativeFuzz(m, Box)
        case Right(r) => r
      }
    case RelativeFuzz(t, thatShape) =>
      // All other combinations → Gaussian via sigmas, subject to the three-tier rules.
      val sigma1 = this.shape match {
        case tr: Trapezoid => tr.sigma
        case Box => Box.toGaussianRelative(tolerance)
        case Gaussian => tolerance
      }
      val sigma2 = thatShape match {
        case tr: Trapezoid => tr.sigma
        case Box => Box.toGaussianRelative(t)
        case Gaussian => t
      }
      Fuzziness.applyRules(sigma1, sigma2) {
        RelativeFuzz(Gaussian.convolutionProduct(sigma1, sigma2, independent), Gaussian)
      } match {
        case Left(m) => RelativeFuzz(m, Gaussian)
        case Right(r) => r
      }
    case _ =>
      throw FuzzyNumberException(s"* operation on incompatible styles: $this, $convolute, shapes: ($shape, ${convolute.shape})")
  }

  /**
    * Yield a Fuzziness[T] that is Gaussian (either this or derivative of this).
    */
  lazy val normalizeShape: Fuzziness[T] = shape match {
    case Gaussian =>
      this
    case Box =>
      RelativeFuzz(Box.toGaussianRelative(tolerance), Gaussian)
    case t: Trapezoid =>
      RelativeFuzz(t.sigma, Gaussian)
  }

  /**
    * Render this Fuzziness as with a given T value.
    *
    * @param t the T value.
    * @return a String which is the textual rendering of t with this Fuzziness applied.
    */
  def getQualifiedString(t: T, forceScientific: Boolean = false): (Boolean, String) =
  {
    lazy val absoluteFuzz = absolute(t)
    lazy val tuple = false -> asPercentage
    lazy val maybeAbsTuple = absoluteFuzz.map(_.getQualifiedString(t, forceScientific))
    (Option.when(tolerance > 0.0001)(tuple) orElse maybeAbsTuple).getOrElse(tuple)
  }

  /**
    * A variation on toString where we render this relative Fuzziness as a percentage.
    * Trailing zeros are stripped (e.g. "0.5%" not "0.50%", "2%" not "2.0%").
    *
    * @return a String which ends with the '%' character.
    */
  def asPercentage: String = {
    val percentage = tolerance * 100

    if (percentage == 0.0) return s"0$Percent"

    val absPercentage = math.abs(percentage)

    // Calculate decimals to show ~2 significant figures
    val decimals = if (absPercentage >= 1) 1
    else math.max(1, -math.floor(math.log10(absPercentage)).toInt + 1)

    BigDecimal(percentage)
      .setScale(decimals, BigDecimal.RoundingMode.HALF_UP)
      .underlying
      .stripTrailingZeros
      .toPlainString + Percent
  }

  /**
    * Determine the range +- t such that the probability of a random point being within that range is `p`,
    * and where tolerance signifies the extent of the PDF.
    * In other words get the wiggle room.
    * NOTE that the greater the value of p, the smaller the result
    *
    * @param confidence the confidence we wish to have in the result: typical value: oneSigma
    * @return the value of t at which the probability density is exactly transitions from likely to not likely.
    */
  def wiggle(confidence: Double = oneSigma): T =
    tv.fromDouble(shape.wiggle(tolerance, confidence))

  /**
    * True.
    */
  val style: Boolean = true
}

/**
  * Absolute Fuzziness.
  *
  * @param magnitude the magnitude of the fuzz.
  * @param shape     the shape of the fuzz.
  * @tparam T the underlying type of the fuzziness. Usually Double for fuzzy numerics.
  */
case class AbsoluteFuzz[T: HasValue](magnitude: T, shape: Shape) extends Fuzziness[T] {
  private val tv = implicitly[HasValue[T]]

  /**
    * This method takes a value of T on which to base a relative fuzz value.
    * NOTE: if t is zero, we will return None, which means the conversion to relative form failed.
    * The caller should keep the original absolute fuzz rather than treating this as an exact number.
    *
    * @param t the nominal value of the fuzzy number.
    * @return an optional RelativeFuzz[T]
    */
  def relative(t: T): Option[RelativeFuzz[T]] = {
    val value = RelativeFuzz(tv.toDouble(tv.normalize(tv.div(magnitude, t))), shape)
    Try(value).toOption
  }

  /**
    * Transform this Fuzziness[T] according to func.
    * Typically, func will be the derivative of the relevant Number function.
    *
    * @param func the function to apply to this Fuzziness[T].
    * @return an (optional) transformed version of Fuzziness[T].
    */
  def transform[U: HasValue, V: HasValue](func: T => V)(t: T): Fuzziness[U] = {
    val duByDt: V = func(t)
    val dU: U = implicitly[HasValue[U]].multiply(magnitude, duByDt)
    AbsoluteFuzz(dU, shape)
  }

  /**
    * Return either a RelativeFuzz equivalent or this, according to relativeStyle.
    *
    * @param t             the magnitude of the relevant Number.
    * @param relativeStyle if true then convert to Absolute otherwise wrap this in Some().
    * @return the (optional) Fuzziness as a Relative or Absolute Fuzziness, according to relative.
    */
  def normalize(t: T, relativeStyle: Boolean): Option[Fuzziness[T]] =
    if (relativeStyle)
      relative(t) match {
        case Some(RelativeFuzz(tol, _)) if !tol.isInfinite && !tol.isNaN =>
          relative(t)
        case _ =>
          Some(this) // Fallback to original absolute fuzz
      }
    else
      Some(this)

  /**
    * Convolves the current instance of `Fuzziness[T]` with another `Fuzziness[T]`
    * instance based on the specified parameters, producing a new `Fuzziness[T]`
    * instance. The behavior of the convolution depends on the shape and magnitude
    * of the `Fuzziness[T]` instances involved.
    *
    * @param convolute   The `Fuzziness[T]` instance to convolve with the current instance.
    * @param independent A boolean indicating whether the two fuzzy distributions are independent.
    * @return A new `Fuzziness[T]` instance as the result of the convolution operation.
    * @throws FuzzyNumberException If the operation involves incompatible styles of fuzzy distributions.
    */
  def *(convolute: Fuzziness[T], independent: Boolean): Fuzziness[T] = convolute match {
    case AbsoluteFuzz(m, Box) if this.shape == Box =>
      // Box ⊗ Box → Trapezoid, subject to the three-tier rules.
      val mA = tv.toDouble(magnitude)
      val mB = tv.toDouble(m)
      Fuzziness.applyRules(mA, mB) {
        val (a, b) = (math.min(mA, mB), math.max(mA, mB))
        AbsoluteFuzz(tv.fromDouble(a + b), Trapezoid(a, b))
      } match {
        case Left(m) => AbsoluteFuzz(tv.fromDouble(m), Box)
        case Right(r) => r
      }
    case AbsoluteFuzz(m, _) =>
      // All other combinations → Gaussian via sigmas, subject to the three-tier rules.
      val sigma1 = this.shape match {
        case tr: Trapezoid => tr.sigma
        case Box => Box.toGaussianRelative(tv.toDouble(magnitude))
        case Gaussian => tv.toDouble(magnitude)
      }
      val sigma2 = convolute.shape match {
        case tr: Trapezoid => tr.sigma
        case Box => Box.toGaussianRelative(tv.toDouble(m))
        case Gaussian => tv.toDouble(m)
      }
      Fuzziness.applyRules(sigma1, sigma2) {
        AbsoluteFuzz(tv.fromDouble(Gaussian.convolutionSum(sigma1, sigma2)), Gaussian)
      } match {
        case Left(m) => AbsoluteFuzz(tv.fromDouble(m), Gaussian)
        case Right(r) => r
      }
    case _ =>
      throw FuzzyNumberException(s"* operation on incompatible styles: $this, $convolute")
  }

  /**
    * This method normalizes the shape of the current Fuzziness[T].
    * If the shape is Gaussian, it returns the current instance.
    * If the shape is Box, it converts the shape to a Gaussian with the same magnitude.
    *
    * @return a Fuzziness[T] object with a normalized Gaussian shape.
    */
  lazy val normalizeShape: Fuzziness[T] = shape match {
    case Gaussian =>
      this
    case Box =>
      AbsoluteFuzz(Box.toGaussianAbsolute(magnitude), Gaussian)
    case t: Trapezoid =>
      AbsoluteFuzz(t.toGaussianAbsolute[T], Gaussian)
  }
  /**
    * Method to do accurate rounding of Double.
    *
    * @param x the double value to be rounded.
    * @param n the number of places to be rounded to.
    * @return the rounded value of x.
    */
  def round(x: Double, n: Int): Double =
    BigDecimal(BigDecimal(math.round(toDecimalPower(x, n)).toInt).bigDecimal.movePointLeft(n)).toDouble

  /**
    * Method to render this Fuzziness according to the nominal value t.
    * NOTE that we are actually embedding the fuzziness into the nominal value and returning that.
    *
    * CONSIDER cleaning this method up a bit.
    *
    * @param t               a T value.
    * @param forceScientific if true, always use scientific notation regardless of value magnitude.
    * @return a tuple of a Boolean (indicating if the value is embedded in the result) and a String which is the textual rendering of t with this Fuzziness applied.
    */
  def getQualifiedString(t: T, forceScientific: Boolean = false): (Boolean, String) = {
    val tDouble = tv.toDouble(t)
    val absValue = math.abs(tDouble)

    // Use scientific notation for values outside [0.001, 10000), OR when the
    // magnitude of the fuzz is >= 1 (uncertainty at or above the units position),
    // OR when forceScientific is explicitly requested (e.g. for asAbsolute).
    //    val magnitudeDouble = tv.toDouble(magnitude)
    val effectiveMagnitudeDouble = shape.effectiveMagnitude(tv.toDouble(magnitude))
    val magnitudeExp = if (effectiveMagnitudeDouble > 0) math.floor(math.log10(effectiveMagnitudeDouble)).toInt else 0
    val useScientific = forceScientific || (absValue != 0.0 && (absValue >= 10000.0 || absValue < 0.001)) || magnitudeExp >= 0
    val scientificFormat = f"$tDouble%.20E"
    val eString = scientificFormat match {
      case AbsoluteFuzz.numberR(e) => e
      case _ => noExponent
    }

    val exponent = Integer.parseInt(eString)

    // Only append E-suffix when we actually want scientific notation
    val scientificSuffix = if (useScientific && eString != noExponent) s"E$eString" else ""

    // Only scale when using scientific notation; otherwise work in natural decimal
    val effectiveExponent = if (useScientific) exponent else 0

    val scaledM = toDecimalPower(effectiveMagnitudeDouble, -effectiveExponent)
    val d = math.log10(scaledM).toInt
    val roundedM = round(scaledM, 2 - d)

    val scaledT = tv.scale(t, toDecimalPower(1, -effectiveExponent))

    val q = f"$roundedM%.99f".substring(2)
    val (qPrefix, qSuffix) = q.toCharArray.span(_ == '0')
    val (qPreSuffix, _) = qSuffix.span(_ != '0')
    val adjust = qPreSuffix.length - 2
    val mScaledAndRounded = toDecimalPower(round(scaledM, qPrefix.length + 2 + adjust), qPrefix.length)
    val yq = mScaledAndRounded.toString.substring(2).padTo(2 + adjust, '0').substring(0, 2 + adjust)
    val brackets = if (shape == Gaussian) "()" else "[]"
    val mask = new String(qPrefix) + "0" * (2 + adjust) + brackets.head + yq + brackets.tail.head

    val (zPrefix, zSuffix) = tv.render(scaledT).toCharArray.span(_ != '.')
    true -> (new String(zPrefix) + "." + zipStrings(new String(zSuffix).substring(1), mask) + scientificSuffix)
  }

  lazy val asPercentage: String = "absolute fuzz cannot be shown as percentage"

  /**
    * Determine the range +- t such that the probability of a random point being within that range is `p`,
    * and where magnitude signifies the extent of the PDF.
    * In other words get the wiggle room.
    * NOTE that the greater the value of p, the smaller the result
    */
  def wiggle(confidence: Double = oneSigma): T =
    tv.fromDouble(shape.wiggle(tv.toDouble(magnitude), confidence))

  /**
    * False.
    */
  val style: Boolean = false

  private val noExponent = "+00"
}

/**
  * The `AbsoluteFuzz` companion object provides utility methods and values related to absolute fuzziness.
  *
  * This object includes a private regular expression pattern, `numberR`, which is used for
  * identifying and matching numbers in scientific notation (e.g., "-1.23E+3").
  *
  * The `AbsoluteFuzz` object serves as a utility companion to the `AbsoluteFuzz` class,
  * enabling various operations involving fuzziness and numerical representation, typically
  * in the context of scientific computation and numerical analysis.
  */
object AbsoluteFuzz {
  /**
    * A private regular expression pattern used to match numbers in scientific notation.
    *
    * The pattern captures floating-point numbers in the form of "-1.23E+3" or "4.56E-2",
    * including optional signs for the exponent. This is primarily used for operations
    * involving parsing or validating numerical inputs in scientific notation.
    */
  private val numberR = """-?\d+\.\d+E([\-+]?\d+)""".r
}

/**
  * A companion object to `Fuzziness` providing methods to manage and manipulate fuzziness in calculations and numeric operations.
  * Fuzziness represents a level of uncertainty or imprecision associated with a value.
  */
object Fuzziness {

  /**
    * Method to yield a transformation (i.e. a Fuzziness[T] => Fuzziness[T]) based on a scale constant k.
    *
    * @param k the scale constant.
    * @tparam T the underlying type.
    * @return a function which will transform a Fuzziness[T] into a Fuzziness[T].
    */
  def scaleTransform[T: HasValue](k: Double): Fuzziness[T] => Fuzziness[T] =
    tf => tf.transform(_ => implicitly[HasValue[T]].fromDouble(k))(implicitly[HasValue[T]].fromInt(1))

  /**
    * Method to represent an optional Fuzziness as a String.
    *
    * @param fo the fuzziness.
    * @return a String which either shows a percentage (ending in '%') or "<exact>".
    */
  def showPercentage(fo: Option[Fuzziness[Double]]): String =
    fo map (_.asPercentage) getOrElse "<exact>"

  /**
    * Scale the fuzz values by the two given coefficients.
    *
    * @param fuzz         the fuzz values (a Tuple), deltaX/X and deltaY/Y.
    * @param coefficients the coefficients (a Tuple): the coefficients of deltaX/X and deltaY/Y respectively.
    * @return the scaled fuzz values (a Tuple).
    */
  def applyCoefficients[T: HasValue](fuzz: (Option[Fuzziness[T]], Option[Fuzziness[T]]), coefficients: Option[(T, T)]): (Option[Fuzziness[T]], Option[Fuzziness[T]]) =
    coefficients match {
      case Some((a, b)) =>
        val f1o = sanitize(fuzz._1 map scaleTransform(implicitly[HasValue[T]].toDouble(a)))
        val f2o = sanitize(fuzz._2 map scaleTransform(implicitly[HasValue[T]].toDouble(b)))
        (f1o, f2o)
      case _ => fuzz
    }

  /**
    * Combine the fuzz values using a convolution.
    * The order of fuzz1 and fuzz2 is not significant.
    * Note that we normalize the style of each fuzz according to the value of `relative`.
    * When both shapes are Box, we convolve them directly to produce a Trapezoid (or Box if one is negligible).
    * When either shape is Trapezoid, we pass directly to `*` which handles all Trapezoid combinations.
    * For all other shape combinations, we normalise to Gaussian before convolving.
    *
    * @param t1          the magnitude of the first operand.
    * @param t2          the magnitude of the second operand.
    * @param relative    true if we are multiplying, false if we are adding.
    * @param independent true if the fuzz distributions are independent.
    * @param fuzz        a Tuple of the two optional Fuzziness values.
    * @tparam T the underlying type of the Fuzziness.
    * @return an Option of Fuzziness[T].
    */
  def combine[T: HasValue](t1: T, t2: T, relative: Boolean, independent: Boolean)(fuzz: (Option[Fuzziness[T]], Option[Fuzziness[T]])): Option[Fuzziness[T]] = {
    val f1o = doNormalize(fuzz._1, t1, relative)
    val f2o = doNormalize(fuzz._2, t2, relative)
    (f1o, f2o) match {
      case (Some(f1), Some(f2)) if f1.shape == Box && f2.shape == Box =>
        // Box ⊗ Box → Trapezoid (or Box if one is negligible): handled directly by *.
        Some(f1.*(f2, independent))
      case (Some(f1), Some(f2)) if f1.shape.isInstanceOf[Trapezoid] || f2.shape.isInstanceOf[Trapezoid] =>
        // Any combination involving a Trapezoid: handled directly by *.
        Some(f1.*(f2, independent))
      case (Some(f1), Some(f2)) =>
        // All other combinations (Gaussian ⊗ Gaussian): normalise shapes to Gaussian first.
        Some(f1.normalizeShape.*(f2.normalizeShape, independent))
      case (Some(f1), None) =>
        Some(f1)
      case (None, Some(f2)) =>
        Some(f2)
      case _ =>
        None
    }
  }

  /**
    * Map the fuzz value with a function (typically the derivative of the function being applied to the Fuzzy quantity).
    * Note that we normalize the style of each fuzz according to the value of `relative`.
    * Note also that we normalize the shape of each fuzz to ensure Gaussian, since we cannot combine Box shapes into Box
    * (we could combine Box shapes into trapezoids but who needs that?).
    *
    * @param t        the magnitude of the input Number.
    * @param u        the magnitude of the output Number.
    * @param relative true if we are multiplying, false if we are adding.
    * @param g        the function with which to transform the given Fuzziness value
    * @param fuzz     one of the (optional) Fuzziness values.
    * @tparam T the underlying type of the incoming Fuzziness.
    * @tparam U the underlying type of the resulting Fuzziness.
    * @tparam V the underlying type of the result divided by the input.
    * @return an Option of Fuzziness[T].
    */
  def map[T, U: HasValue, V: HasValue](t: T, u: U, relative: Boolean, g: T => V, fuzz: Option[Fuzziness[T]]): Option[Fuzziness[U]] = {
    val q: Option[Fuzziness[U]] = fuzz match {
      case Some(f1) =>
        Some(f1.transform(g)(t))
      case _ =>
        None
    }
    doNormalize(q, u, relative)
  }

  /**
    * This method creates fuzz based on the practical limitations of representations and functions in double-precision arithmetic.
    * See also the method doublePrecision.
    *
    * @param relativePrecision the approximate number of bits of additional imprecision caused by evaluating a function.
    * @return the approximate precision for a floating point operation, expressed in terms of RelativeFuzz.
    */
  def createFuzz(relativePrecision: Option[Int]): Option[Fuzziness[Double]] =
    relativePrecision map (f => RelativeFuzz[Double](DoublePrecisionTolerance * (1 << f), Box))

  /**
    * Creates an absolute fuzziness value with the given magnitude.
    *
    * @param magnitude The magnitude of the fuzziness to be created.
    *                  This specifies the degree to which a value's precision is uncertain.
    * @return An `Option` containing the created `Fuzziness[Double]`
    *         with the specified magnitude, or `None` if the fuzziness could not be created.
    */
  def createAbsFuzz(magnitude: Double): Option[Fuzziness[Double]] =
    Some(AbsoluteFuzz(magnitude, Box))

  /**
    * This is the (approximate) fuzziness caused in general by trying to represent numbers in double precision.
    * Of course, many numbers can be represented exactly by double-precision. But not all.
    *
    * @return a Fuzziness[Double].
    */
  lazy val doublePrecision: Fuzziness[Double] = RelativeFuzz[Double](DoublePrecisionTolerance, Box)

  /**
    * The ratio above which one fuzz distribution is considered negligible relative to another.
    * If the larger is more than this many times the smaller, the smaller is ignored and
    * the larger is returned unchanged (preventing spurious shape promotion).
    * A ratio of 9 means: a 10x or greater difference suppresses combination.
    */
  val negligibleRatio: Double = 9.0

  /**
    * The floor below which a fuzz magnitude is considered pure double-precision noise.
    * Two fuzz values both below this threshold are combined by scaling the larger by sqrt(2),
    * rather than by full convolution, to avoid spurious shape promotion.
    */
  val doublePrecisionFloor: Double = DoublePrecisionTolerance * 2 // ≈ 4.4E-16

  /**
    * Represents a predefined constant, oneSigma, used to define a confidence interval
    * or tolerance level in mathematical or statistical computations.
    * The value of this constant is 0.317, which may be interpreted as within one standard deviation..
    */
  val oneSigma: Double = 0.317

  /**
    * A constant value representing the square root of 2.
    * This is used when combining two equal fuzz values without changing the underlying shape.
    */
  val simpleDoubleFuzzFactor: Double = math.sqrt(2)

  /**
    * Sanitize an optional Fuzziness value by returning None if its magnitude
    * is NaN or infinite. This prevents NaN from propagating into combination
    * logic (e.g. Trapezoid constructor) when derivatives are undefined.
    *
    * @param f the optional Fuzziness to sanitize.
    * @tparam T the underlying type.
    * @return the original value, or None if the magnitude is NaN or infinite.
    */
  private def sanitize[T: HasValue](f: Option[Fuzziness[T]]): Option[Fuzziness[T]] =
    f.filter {
      case AbsoluteFuzz(m, _) => val x = implicitly[HasValue[T]].toDouble(m); !x.isNaN && !x.isInfinite
      case RelativeFuzz(t, _) => !t.isNaN && !t.isInfinite
    }

  /**
    * Apply the three-tier combination rules to two fuzz magnitudes and shapes,
    * returning the effective (combinedMagnitude, combinedShape):
    *
    * Rule 1 - Double-precision floor: if either magnitude < doublePrecisionFloor,
    * scale the larger by sqrt(2), keep its shape.
    * Rule 2 - Negligible ratio: if larger/smaller > negligibleRatio (9),
    * return the larger unchanged.
    * Rule 3 - Full convolution: delegate to the caller via the supplied function.
    *
    * @param m1       magnitude of the first fuzz.
    * @param m2       magnitude of the second fuzz.
    * @param convolve a by-name function to perform the full convolution when Rules 1 and 2 don't apply.
    * @tparam T the underlying fuzz type.
    * @return the result of applying the appropriate rule.
    */
  private[numerical] def applyRules[T](m1: Double, m2: Double)(convolve: => T): Either[Double, T] = {
    if (m1.isNaN || m2.isNaN || m1 == 0.0 || m2 == 0.0)
      Left(math.max(m1, m2)) // Guard: NaN or zero — keep the valid one
    else {
      val (small, large) = (math.min(m1, m2), math.max(m1, m2))
      if (large / small > negligibleRatio)
        Left(large) // Rule 2: negligible — keep larger
      else if (small < doublePrecisionFloor)
        Left(large * simpleDoubleFuzzFactor) // Rule 1: floor — scale by sqrt(2)
      else
        Right(convolve) // Rule 3: full convolution
    }
  }

  /**
    * Normalize the magnitude qualifier of the given fuzz according to relative.
    * If `relative` is true then the returned value will be a RelativeFuzz.
    * If `relative` is false then the returned value will be an AbsoluteFuzz.
    *
    * @param fuzz     the optional Fuzziness to work on.
    * @param t        the value of T that the fuzz IS or result SHOULD BE relative to.
    * @param relative if true then return optional relative fuzz, else absolute fuzz.
    * @tparam T the underlying type of the Fuzziness.
    * @return the optional Fuzziness value which is equivalent (or identical) to fuzz, according to the value of relative.
    */
  private def doNormalize[T: HasValue](fuzz: Option[Fuzziness[T]], t: T, relative: Boolean): Option[Fuzziness[T]] =
    fuzz.flatMap(f => doNormalize(t, relative, f))

  /**
    * Combines two strings by replacing characters from the first string with
    * corresponding characters from the second string whenever they are non-zero ('0').
    *
    * NOTE used by `AbsoluteFuzz.toString`
    *
    * @param v the first string to process, with characters to be potentially replaced.
    * @param t the second string providing replacement characters.
    * @return a new string where characters from the first string are replaced
    *         by non-zero characters from the second string at the same positions.
    */
  def zipStrings(v: String, t: String): String = {
    val cCs = ((LazyList.from(v.toCharArray.toList) :++ LazyList.continually('0')) zip t.toCharArray.toList).toList
    val r: List[Char] = cCs map {
      case (a, b) => if (b == '0') a else b
    }
    new String(r.toArray)
  }

  /**
    * Apply a decimal exponent of n to x and return the new value.
    * CONSIDER using BigDecimal for more precision (see AbsoluteFuzz.round)
    *
    * @param x a Double.
    * @param n the size of the exponent.
    * @return the result.
    */
  def toDecimalPower(x: Double, n: Int): Double = x * math.pow(10, n)

  /**
    * Normalizes the given fuzziness based on its type and whether the result should be relative or absolute.
    * If the provided fuzziness is of type `AbsoluteFuzz`, it converts it to a relative type if `relative` is true.
    * If the fuzziness is of type `RelativeFuzz`, it converts it to an absolute type if `relative` is false.
    *
    * @param t        the value of T that the fuzziness is or should be relative to.
    * @param relative if true, the returned fuzziness should be of type `RelativeFuzz`; otherwise, it should be of type `AbsoluteFuzz`.
    * @param f        the fuzziness to normalize, which can be either `AbsoluteFuzz` or `RelativeFuzz`.
    * @tparam T the underlying type of the fuzziness.
    * @return an optional normalized fuzziness based on the given parameters.
    */
  private def doNormalize[T](t: T, relative: Boolean, f: Fuzziness[T]) =
    f match {
      case a@AbsoluteFuzz(_, _) =>
        if (relative) a.relative(t) else Some(f)
      case r@RelativeFuzz(_, _) =>
        if (relative) Some(f) else r.absolute(t)
    }

  /**
    * Calculate the fuzziness for the result of a MonadicOperation.
    *
    * NOTE: the parameter x is not actually used in this method. It seems like it ought to be used for functionFuzz
    * but the values produced this way do seem to be correct.
    * It is possible that the values are correct for relative error bounds but maybe not for absolute error bounds.
    *
    * @param op   the monadic operation.
    * @param t    the magnitude of the input to the monadic operation.
    * @param x    the magnitude of the result of the monadic operation.
    * @param fuzz the (optional) fuzziness of input to the monadic operation.
    * @return the optional fuzziness for the result of the monadic operation.
    */
  def monadicFuzziness(op: MonadicOperation, t: Double, x: Double, fuzz: Option[Fuzziness[Double]]): Option[Fuzziness[Double]] = {
    val useRelativeFuzz = op.fuzz.isDefined
    // CONSIDER using map again (which itself uses transform) -- but be careful!
    // First, ensure that the fuzz we are given is relative if the operation is not an exact operation.
    val relativeFuzz: Option[Fuzziness[Double]] = fuzz flatMap (_.normalize(t, relative = useRelativeFuzz))
    // Next, calculate the relative fuzziness of the result, according to the function being applied.
    val functionFuzz: Option[Fuzziness[Double]] = sanitize(relativeFuzz map (_.transform(op.relativeFuzz)(t)))
    // Finally, we calculate the precision loss (if any) occasioned by the actual implementation of the operation function itself.
    val operationFuzz = sanitize(createFuzz(op.fuzz))
    // Combine the functionFuzz with the operationFuzz
    combine(t, t, relative = useRelativeFuzz, independent = true)((functionFuzz, operationFuzz))
    //      ^  ^ <-- Use 'x' (output value) for both, since both errors are now relative to the output
  }
}

/**
  * Describes a probability density function for a continuous distribution.
  * NOTE: this isn't suitable for discrete distributions, obviously.
  *
  * CONSIDER: implement additional shapes, for example O(f(x)). This would be used for the Basel problem, for example.
  */
trait Shape {

  /**
    * Determine the half-width δ such that the cumulative probability P(-δ, δ) = 1 - confidence.
    * In other words, get the wiggle room: the range within which a random point will fall
    * with probability (1 - confidence).
    * NOTE that the greater the value of confidence, the smaller the resulting wiggle room.
    *
    * @param l          the scale of the PDF (e.g. standard deviation for Gaussian, half-width for Box).
    * @param confidence the tail probability: the probability of a random point falling
    *                   *outside* the range [-δ, δ]. Typical value: oneSigma.
    * @return δ, the half-width of the symmetric interval around the mean.
    */
  def wiggle(l: Double, confidence: Double = oneSigma): Double

  /**
    * Computes the probability that random points will be found with the range `-x` to `+x` where `l` is a measure of this size of this shape.
    *
    * @param l the size or scale of the probability density function (e.g., standard deviation for a Gaussian distribution).
    * @param x the specific point that bounds the region we're interested in.
    * @return the calculated probability density at the given point.
    */
  def probability(l: Double, x: Double): Double

  /**
    * Computes the effective magnitude for the given scale parameter of the distribution.
    *
    * @param l the scale of the probability density function (e.g., standard deviation for Gaussian, half-width for Box).
    * @return the effective magnitude as a derived measure based on the provided scale.
    */
  def effectiveMagnitude(l: Double): Double
}

/**
  * Uniform probability density over a specific range, otherwise zero.
  * CONSIDER making this a case class with a member corresponding to the `l` value of wiggle.
  */
case object Box extends Shape {
  /**
    * See, for example, https://www.unf.edu/~cwinton/html/cop4300/s09/class.notes/Distributions1.pdf
    */
  private val uniformToGaussian =
    1.0 / math.sqrt(3)

  /**
    * This method is to simulate a uniform distribution
    * with a normal distribution.
    *
    * @param x half the length of the basis of the uniform distribution.
    * @return x/2 which will be used as the standard deviation.
    */
  def toGaussianRelative(x: Double): Double =
    x * uniformToGaussian

  /**
    * This method is to simulate a uniform distribution
    * with a normal distribution.
    *
    * @param t the magnitude of the Box distribution.
    * @return t/2 which will be used as the standard deviation.
    */
  def toGaussianAbsolute[T: HasValue](t: T): T =
    implicitly[HasValue[T]].scale(t, uniformToGaussian)

  /**
    * Calculates an adjusted scale or measure for a given size or range, based on the specified confidence level.
    *
    * - If confidence is 0.0, it returns positive infinity, representing maximum uncertainty.
    * - If confidence is 1.0, it returns 0, representing no variability.
    * - For other confidence levels, it returns half the input size `l`.
    *
    * @param l          the size or scale of the probability density function (e.g., the width of the uniform distribution).
    * @param confidence the confidence level, where 0.0 represents no certainty and 1.0 represents full certainty.
    * @return the adjusted scale or measure based on the confidence level.
    */
  def wiggle(l: Double, confidence: Double = oneSigma): Double = confidence match {
    case 0.0 =>
      Double.PositiveInfinity
    case 1.0 =>
      0
    case _ =>
      l / 2
  }

  /**
    * Computes the probability that random points will be found with the range `-x` to `+x` where `l` half the width of the box.
    *
    * @param l the size or scale of the probability density function (e.g., standard deviation for a Gaussian distribution).
    * @param x the specific point that bounds the region we're interested in (this number is always positive)
    * @return the calculated probability density at the given point.
    */
  def probability(l: Double, x: Double): Double = x match {
    case y if y <= 0.0 => 0.0
    case y if y >= l => 1.0
    case _ => x / l
  }

  /**
    * Calculates the effective magnitude of a given size or scale.
    * This method is used to evaluate the effective magnitude associated
    * with specific properties of a distribution.
    *
    * @param l the size or scale of the distribution (e.g., width or extent).
    * @return the effective magnitude for the given input size or scale.
    */
  def effectiveMagnitude(l: Double): Double = l
}

/**
  * A trapezoidal probability distribution, arising from the convolution of two Box distributions.
  * The flat top has half-width (b-a) and the ramps extend to (a+b).
  * NOTE: unlike Box and Gaussian which are case objects with `l` passed as a parameter to `wiggle`,
  * Trapezoid carries its own scale parameters `a` and `b`. The `l` parameter of `wiggle` and
  * `probability` is therefore ignored. TODO: at some future point, refactor Box and Gaussian
  * similarly, moving `l` into the case class/object.
  *
  * @param a the half-width of the smaller of the two constituent Box distributions (a <= b).
  * @param b the half-width of the larger of the two constituent Box distributions.
  */
case class Trapezoid(a: Double, b: Double) extends Shape {
  require(a <= b, s"Trapezoid requires a <= b, got a=$a, b=$b")

  /**
    * The standard deviation of this Trapezoid distribution, derived from the sum of variances
    * of the two constituent Box distributions: Var = a²/3 + b²/3 = (a²+b²)/3.
    */
  val sigma: Double = math.sqrt((a * a + b * b) / 3.0)

  /**
    * Convert this Trapezoid to an equivalent Gaussian AbsoluteFuzz.
    * Used when further convolution is required (n >= 3 Box distributions).
    */
  def toGaussianAbsolute[T: HasValue]: T =
    implicitly[HasValue[T]].fromDouble(sigma)

  /**
    * Computes a value based on the given confidence level. The method distinguishes between two regions:
    * a flat-top region where the result is independent of confidence, and a ramp region where the result
    * depends on confidence. Special cases are handled for confidence values of 0.0 and 1.0.
    * NOTE: the `l` parameter is ignored since scale is encoded in `a` and `b`.
    *
    * @param l          a parameter intended for use in computations (currently not utilized).
    * @param confidence a value between 0.0 and 1.0 representing the level of certainty or probability.
    * @return a computed double value based on the given confidence level.
    */
  def wiggle(l: Double, confidence: Double): Double = confidence match {
    case 0.0 => Double.PositiveInfinity
    case 1.0 => 0.0
    case _ =>
      val threshold = a / b
      if (a < b && confidence > threshold)
        b - a // flat-top region: independent of confidence, like Box
      else
        (a + b) - 2 * math.sqrt(a * b * confidence) // ramp region
  }

  /**
    * Computes the probability that a random point falls within [-x, x].
    * NOTE: the `l` parameter is ignored since scale is encoded in `a` and `b`.
    *
    * @param l ignored.
    * @param x the half-width of the region of interest.
    * @return the probability.
    */
  def probability(l: Double, x: Double): Double = x match {
    case y if y <= 0.0 => 0.0
    case y if y >= a + b => 1.0
    case y if y <= b - a => y / b // flat-top region
    case y => // ramp region
      (b - a) / b + (1.0 / (4 * a * b)) * (4 * a * a - (a + b - y) * (a + b - y))
  }

  /**
    * Calculates the effective magnitude of the trapezoid based on the given parameter.
    * The calculation leverages the `sigma` field of the trapezoid.
    *
    * @param l (ignored)
    * @return the effective magnitude as a double value, derived from the trapezoid's characteristics.
    */
  def effectiveMagnitude(l: Double): Double = sigma
}

/**
  * A "normal" probability distribution function.
  * CONSIDER making this a case class with a member corresponding to the `l` value of wiggle.
  */
case object Gaussian extends Shape {
  /**
    * Get the convolution of sum of two Gaussian distributions.
    *
    * This follows the fact that Var(X + Y) = Var(X) + Var(Y)
    *
    * See https://en.wikipedia.org/wiki/Variance
    *
    * @param sigma1 the first standard deviation.
    * @param sigma2 the second standard deviation.
    * @return a double which is the root-mean-square of the sigmas.
    */
  def convolutionSum(sigma1: Double, sigma2: Double): Double =
    rootSumSquares(sigma1, sigma2)

  /**
    * For the convolution of the product of two (independent) Gaussian distributions (see https://en.wikipedia.org/wiki/Variance).
    * You must not use this expression when multiplying a fuzzy number by itself, for example, because then they are not independent.
    *
    * Var(X Y) = mux mux Var(Y) + muy muy Var(X) + Var(X) Var(Y)
    *
    * Therefore, (sigma(x*y))**2 = (mux sigma(y))**2 + (muy sigma(x))**2 + (sigma(x) sigma(y))**2
    *
    * Or, dividing by (mux muy)**2 (i.e., using relative variations)
    *
    * sigma(x/mux 8 y/muy)**2 = sigma(x/mux)**2 + sigma(y/muy)**2 + (sigma(x/mux) sigma(y/muy))**2
    *
    * @param sigma1      the first standard deviation.
    * @param sigma2      the second standard deviation.
    * @param independent whether the distributions are independent.
    * @return
    */
  def convolutionProduct(sigma1: Double, sigma2: Double, independent: Boolean): Double =
    if (independent)
      convolution(sigma1, sigma2)
    else
      sigma1 + sigma2

  /**
    * Adjusts the given value based on the specified confidence level, using the properties
    * of a Gaussian distribution.
    *
    * @param l          the scale or size parameter, typically representing the standard deviation of a Gaussian distribution.
    * @param confidence the confidence level, a value between 0 and 1, representing the desired probability threshold.
    * @return a double representing the adjusted value based on the confidence level and scale.
    */
  def wiggle(l: Double, confidence: Double = oneSigma): Double =
    l / sigma * erfInv(1 - confidence)

  /**
    * Computes the probability that random points will be found with the range `-x` to `+x` where `l` is the standard deviation of this Gaussian.
    *
    * @param l the size or scale of the probability density function (e.g., standard deviation for a Gaussian distribution).
    * @param x the specific point that bounds the region we're interested in.
    * @return the calculated probability density at the given point.
    */
  def probability(l: Double, x: Double): Double = x match {
    case Double.PositiveInfinity =>
      1
    case _ =>
      erf(x * sigma / l)
  }

  /**
    * The standard deviation of a normal distribution whose variance is 1/2.
    * This is the basis of the inverse error function.
    */
  val sigma: Double =
    math.sqrt(0.5)

  /**
    * Computes the effective magnitude of a Gaussian distribution based on the input parameter.
    *
    * @param l the scale parameter, typically representing the standard deviation of a Gaussian distribution.
    * @return a double representing the effective magnitude.
    */
  def effectiveMagnitude(l: Double): Double = l
}

/**
  * Represents a trait that provides an optional fuzzy characteristic.
  *
  * This trait is used to encapsulate fuzziness-related behavior.
  * The fuzziness is represented as an optional value of type `Fuzziness[Double]`.
  *
  * Suitable when there's a need to describe uncertain or imprecise values
  * through a specific fuzziness model.
  */
trait WithFuzziness {
  /**
    * Retrieves an optional fuzziness value associated with this instance.
    *
    * The fuzziness value, if present, provides information about the level of uncertainty
    * or imprecision, modeled as a `Fuzziness[Double]`.
    *
    * @return an `Option` containing the `Fuzziness[Double]` value if defined, or `None` if no fuzziness is specified.
    */
  def fuzz: Option[Fuzziness[Double]]
}

/**
  * Companion object for the `WithFuzziness` trait.
  *
  * This object provides utility constants or values related to fuzziness.
  * It serves as a container for any shared definitions or configuration
  * that may support implementations of the `WithFuzziness` trait.
  *
  * @define Ellipsis A constant string value representing an ellipsis ("...").
  *                  This might be used as a placeholder or to indicate omissions in certain contexts.
  */
object WithFuzziness {
  val Ellipsis: String = "..."
  val Asterisk: String = "*"
  val GaussianOpen: String = "("
  val GaussianClose: String = ")"
  val BoxOpen: String = "["
  val BoxClose: String = "]"

  // Or for the bracket patterns
  val GaussianPattern: Regex = """\((\d{1,2})\)""".r
  val BoxPattern: Regex = """\[(\d{1,2})]""".r

  // And for repeating sequences
  val RepeatOpen: String = "<"
  val RepeatClose: String = ">"
}

/**
  * Trait which models the behavior of something with (maybe) fuzziness.
  *
  * See also related trait Fuzzy[X] but note that there, the parametric type X
  * corresponds to the quantity itself, not its fuzziness.
  *
  * @tparam T the type of fuzziness.
  */
trait Fuzz[T] extends WithFuzziness {

  /**
    * Adds the provided fuzziness to the current `Fuzz[T]` and returns the resulting value.
    * This method may utilize the fuzziness parameter for calculations where applicable.
    *
    * @param f the fuzziness to add, represented as a Fuzziness[T].
    * @return a Number that represents the result of adding the provided fuzziness.
    */
  def addFuzz(f: Fuzziness[T]): Fuzz[Double]

  /**
    * Creates a fuzziness value with zero magnitude and a Gaussian distribution.
    * This method provides a representation of deterministic or non-fuzzy values
    * by ensuring that the fuzziness magnitude is explicitly zero.
    *
    * @tparam U a supertype of T that also satisfies the HasValue type class constraint.
    * @return a Fuzziness[U] instance with zero magnitude and Gaussian shape.
    */
  def noFuzz[U >: T : HasValue]: Fuzziness[U] =
    AbsoluteFuzz(implicitly[HasValue[U]].fromDouble(0), Gaussian)
}

/**
  * Type class trait HasValue[T].
  *
  * This is used to represent quantities of different underlying units/dimensions.
  *
  * @tparam T the underlying type of this HasValue.
  */
trait HasValue[T] extends Fractional[T] {
  /**
    * Method to return a String representation of a T value.
    *
    * @param t a T value.
    * @return the corresponding String.
    */
  def render(t: T): String

  /**
    * Method to yield a T from a Double.
    *
    * @param x a Double.
    * @return the corresponding value of T.
    */
  def fromDouble(x: Double): T

  /**
    * Method to scale a T value, according to a constant.
    *
    * This is essentially the inverse of the ratio method.
    *
    * @param t a T value.
    * @param f a factor (a Double, i.e., dimensionless).
    * @return a scaled value of T.
    */
  def scale(t: T, f: Double): T

  /**
    * Method to yield a "normalized" version of x.
    * For a Numeric object, this implies the absolute value, i.e., with no sign.
    *
    * @param x the value.
    * @return the value, without any sign.
    */
  def normalize(x: T): T

  /**
    * Method to multiply a `U` by a `V`, resulting in a `T`.
    *
    * @param u a `U` value.
    * @param v a `V` value.
    * @tparam U the type of u.
    * @tparam V the type of v.
    * @return a T whose value is u * v.
    */
  def multiply[U: HasValue, V: HasValue](u: U, v: V): T =
    fromDouble(implicitly[HasValue[U]].toDouble(u) * implicitly[HasValue[V]].toDouble(v))
}

/**
  * Trait HasValueDouble provides functionality for manipulating `Double` values
  * within the context of the `HasValue` type class. It extends the behavior of
  * `HasValue[Double]`, `DoubleIsFractional`, and `Ordering.Double.IeeeOrdering` to
  * work specifically with `Double`-typed quantities, offering operations like rendering,
  * scaling, and normalizing `Double` values.
  *
  * The default implementation of `render` provides a convenient string
  * representation of a `Double`, either in fixed-point or scientific notation
  * depending on the value.
  */
trait HasValueDouble extends HasValue[Double] with DoubleIsFractional with Ordering.Double.IeeeOrdering {
  /**
    * Renders a `Double` value as a string, choosing between fixed-point or
    * scientific notation representation based on specific criteria.
    *
    * @param t the `Double` value to be rendered.
    * @return a string representation of the `Double` value in either
    *         fixed-point or scientific notation format.
    */
  def render(t: Double): String = {
    val absValue = math.abs(t)

    // Use scientific notation only for values outside [0.001, 10000).
    // Within that range always stay decimal, even if the fractional part is all zeros
    // (e.g. 100.0 must not be scaled to 1.0E+02 during mask calculation).
    if (absValue != 0.0 && (absValue >= 10000.0 || absValue < 0.001)) {
      f"$t%.20E"
    } else {
      f"$t%.99f"
    }
  }

  /**
    * Converts the input `Double` value and returns it as-is.
    *
    * @param x the `Double` value to be processed.
    * @return the same `Double` value provided as input.
    */
  def fromDouble(x: Double): Double = x

  /**
    * Scale the parameter x by the constant factor f.
    *
    * @param t a value.
    * @param f a factor.
    * @return x * f.
    */
  def scale(t: Double, f: Double): Double = t * f

  /**
    * Method to yield a "normalized" version of x.
    * For a Numeric object, this implies the absolute value, i.e. with no sign.
    *
    * @param x the value.
    * @return the value, without any sign.
    */
  def normalize(x: Double): Double =
    math.abs(x)
}

/**
  * Companion object for the HasValue type class.
  *
  * This object provides an implicit implementation of the HasValue type class
  * for Double values through the HasValueDouble trait.
  *
  * The HasValue type class is designed to represent a type that can interoperate
  * with fractional operations, scaling, normalization, and rendering to a string.
  */
object HasValue {
  /**
    * An implicit object extending `HasValueDouble`, providing functionality for
    * working with `Double` values within the `HasValue` type class.
    *
    * This object offers default implementations of operations such as rendering,
    * scaling, normalization, and fractional operations for `Double` values.
    *
    * As an implicit object, it allows for automatic resolution of the `HasValue`
    * type class for `Double` values in relevant contexts.
    */
  implicit object HasValueDouble$ extends HasValueDouble

}