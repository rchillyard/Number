/*
 * Copyright (c) 2023. Phasmid Software
 */

package com.phasmidsoftware.number.core.numerical

import com.phasmidsoftware.number.core.inner.*
import com.phasmidsoftware.number.core.numerical.Fuzziness.{combine, oneSigma}
import com.phasmidsoftware.number.core.numerical.FuzzyNumber.withinWiggleRoom
import com.phasmidsoftware.number.core.numerical.Number.prepareWithSpecialize
import com.phasmidsoftware.number.core.numerical.WithFuzziness.{Asterisk, Ellipsis}

import scala.collection.mutable

/**
  * This class is designed to model a fuzzy Number.
  * See GeneralNumber for more details on the actual representation.
  *
  * CONSIDER FuzzyNumber should be the "norm." ExactNumber is just a fuzzy number with None for fuzz.
  * I suspect that this inversion of logic might be the cause of some stack overflows that occur for some ignored tests.
  *
  * TODO ensure that every Double calculation contributes fuzziness.
  *
  * NOTE it is not necessary to override compareTo because the operative method is signum for all Number comparisons,
  * and that is overridden here.
  *
  * CONSIDER implementing equals (but be careful!). Don't implement it in terms of compare(...)==0 or Same.
  *
  * @param nominalValue the (nominal) value of the Number, expressed as a nested Either type.
  * @param factor       the scale factor of the Number: valid scales are: PureNumber, Radian, and NatLog.
  * @param fuzz         the fuzziness of this Number.
  */
case class FuzzyNumber(override val nominalValue: Value, override val factor: Factor, override val fuzz: Option[Fuzziness[Double]]) extends GeneralNumber(nominalValue, factor, fuzz) with Fuzz[Double] {
  /**
    * Method to determine if this NumberLike object is exact.
    * For instance, Number.pi is exact, although if you converted it into a PureNumber, it would no longer be exact.
    *
    * @return true if this NumberLike object is exact in the context of No factor, else false.
    */
  lazy val isExact: Boolean =
    fuzz.isEmpty

  /**
    * Method to determine if this FuzzyNumber is equivalent to another Numerical (x).
    *
    * @param x the other numerical.
    * @return true if they are the same, otherwise false.
    */
  def isSame(x: Numerical): Boolean = x match {
    case Real(n) =>
      isSame(n)
    case n: Number =>
      fuzzyCompare(n) == 0
    case c: Complex =>
      c.isSame(Real(this))
  }

  /**
    * Method to force the fuzziness of this FuzzyNumber to be absolute.
    * CONSIDER why do we make the fuzziness absolute here?
    *
    * @return the same FuzzyNumber but with absolute fuzziness.
    */
  lazy val normalizeFuzz: Number = this match {
    case FuzzyNumber(value, factor, maybeFuzz) =>
      val relativeFuzz = for {
        x <- toNominalDouble
        fuzz <- maybeFuzz
        normalized <- fuzz.normalize(x, relative = false)
      } yield normalized
      FuzzyNumber(value, factor, relativeFuzz)
  }

  /**
    *
    * @return either this Number or a simplified Number.
    */
  lazy val simplify: Number = fuzz match {
    case None =>
      ExactNumber(nominalValue, factor).simplify
    case _ =>
      factor match {
        case NthRoot(_) => scale(PureNumber)
        case _ => this
      }
  }

  /**
    * Add a Number to this FuzzyNumber.
    *
    * @param x the addend.
    * @return the sum.
    */
  def doAdd(x: Number): Number =
    FuzzyNumber.plus(this, x) // NOTE: required but why?

  /**
    * Multiply a Number by this FuzzyNumber.
    *
    * @param x the multiplicand.
    * @return the product.
    */
  def doMultiply(x: Number): Number =
    FuzzyNumber.times(this, x) // NOTE: required but why?

  /**
    * Raise this Number to the power p.
    * NOTE this method can be eliminated but the unit tests will be a little off. Need to understand exactly why.
    *
    * @param p a Number.
    * @return this Number raised to power p.
    */
  def doPower(p: Number): Number =
    FuzzyNumber.power(this, p)

  /**
    * Method to compare this FuzzyNumber with another Number.
    *
    * NOTE it appears that this method can be eliminated but the unit tests would not work without it.
    * Presumably, this is because the implicit equality checks in ScalaTest invoke compare. (?)
    *
    * @param other the other Number.
    * @return -1, 0, or 1 according to whether x is <, =, or > y.
    */
  def compare(other: Number): Int =
    fuzzyCompare(other)

  /**
    * NOTE this method can be eliminated but the compare query operation doesn't appear to take fuzziness into account.
    *
    * @return true if this Number is equivalent to zero with at least 50% confidence.
    */
  lazy val isZero: Boolean =
    isProbablyZero()

  /**
    * Method to determine the sense of this number: negative, zero, or positive.
    * If this FuzzyNumber cannot be distinguished from zero with better than evens confidence, then
    *
    * NOTE this method can be eliminated but the unit tests will be off. Need to understand exactly why.
    *
    * @return an Int which is negative, zero, or positive according to the magnitude of this.
    */
  lazy val signum: Int =
    signum()

  /**
    * Method to determine the sense of this number: negative, zero, or positive.
    * If this FuzzyNumber cannot be distinguished from zero with p confidence, then
    *
    * @param confidence the confidence desired.
    * @return an Int which is negative, zero, or positive according to the magnitude of this.
    */
  def signum(confidence: Double = oneSigma): Int =
    if (isProbablyZero(confidence)) 0 else Number.signum(this)

  /**
    * @param confidence the confidence desired. Ignored if isZero is true.
    * @return true if this Number is equivalent to zero with at least p confidence.
    */
  def isProbablyZero(confidence: Double = oneSigma): Boolean =
    GeneralNumber.isZero(this) || (for (f <- fuzz; x <- toNominalDouble) yield withinWiggleRoom(confidence, f, x)).getOrElse(false)

  /**
    * Evaluate a dyadic operator on this and other, using either plus, times, ... according to the value of op.
    * NOTE: this and other must have been aligned by type so that they have the same structure.
    *
    * @param other        the other operand, a Number.
    * @param f            the factor to apply to the result.
    * @param op           the appropriate DyadicOperation.
    * @param independent  true if the fuzziness of the operands are independent.
    * @param coefficients an optional Tuple representing the coefficients to scale the fuzz values by.
    *                     For a power operation such as x to the power of y, these will be y/x and ln x respectively.
    *                     For addition or multiplication, they will be 1 and 1.
    * @return a new Number which is result of applying the appropriate function to the operands this and other.
    */
  def composeDyadicFuzzy(other: Number, f: Factor)(op: DyadicOperation, independent: Boolean, coefficients: Option[(Double, Double)]): Option[Number] =
    for (n <- composeDyadic(other, f)(op); t1 <- this.toNominalDouble; t2 <- other.toNominalDouble) yield {
      val q = combine(t1, t2, !op.absolute, independent)(Fuzziness.applyCoefficients((fuzz, other.fuzz), coefficients))
      FuzzyNumber(n.nominalValue, n.factor, q)
    }

  /**
    * Render this FuzzyNumber as a String representation.
    *
    * @return a String representation of this FuzzyNumber.
    */
  lazy val render: String = {
    val sb = new mutable.StringBuilder()
    lazy val valueAsString = Value.valueToString(nominalValue, skipOne = false, exact = fuzz.isEmpty)
    val z = fuzz match {
      // CONSIDER will the following test work in all cases?
      case Some(f) if f.wiggle() > 1E-16 =>
        f.getQualifiedString(toNominalDouble.getOrElse(0.0))
      case Some(_) =>
        true -> (valueAsString.replace(Ellipsis, "") + Asterisk)
      case None =>
        true -> valueAsString
    }
    val ww = z match {
      case (true, s) =>
        s
      case (false, s) =>
        valueAsString + "\u00B1" + s
    }
    // TODO Improve this.
    //  Currently, this is a hack but other places essentially do this same thing but I'm having a hard time merging the appropriate code.
    val w = ww.replaceAll("""0\[5]""", Asterisk)

    factor match {
      case Logarithmic(_) =>
        sb.append(factor.render(w))
      case Scalar(_) =>
        sb.append(w)
        sb.append(factor.toString)
      case InversePower(_) =>
        sb.append(factor.render(w))
      case _ =>
        throw CoreException(s"factor is not matched: $factor")
    }
    sb.toString
  }

  /**
    * Show this FuzzyNumber in a human-friendly manner.
    * If render produces a `*`-style result (e.g. "9.81*"), that is already
    * human-friendly and is returned as-is.
    * Otherwise, computes a percentage form with the value rounded to appropriate
    * significant figures (e.g. "0.785±2%"). Returns whichever of render or
    * percentage form is shorter — this favours precise Gaussian notation
    * (e.g. "1836.15267343(11)") over a verbose percentage equivalent, while
    * still preferring percentage for values with excessive double-precision digits.
    * Falls back to render if percentage conversion is not possible.
    *
    * @return a String
    */
  override lazy val show: String = fuzz match
    case None =>
      render
    case Some(f) =>
      val rendered = render
      if rendered.contains('*') then
        rendered
      else
        val v = toNominalDouble.getOrElse(0.0)
        f.normalize(v, relative = true) match
          case Some(relFuzz) =>
            val tolerance = relFuzz.wiggle()
            val valueStr = FuzzyNumber.roundToSigFigs(v, FuzzyNumber.sigFigsForTolerance(tolerance))
            val percentageForm = s"$valueStr\u00B1${relFuzz.asPercentage}"
            if percentageForm.length < rendered.length then percentageForm
            else rendered
          case None =>
            rendered

  /**
    * Make a copy of this Number, given the same degree of fuzziness as the original.
    * Both the nominalValue and the factor will be changed.
    *
    * @param v the nominalValue.
    * @param f the factor.
    * @return a FuzzyNumber.
    */
  def make(v: Value, f: Factor): Number =
    FuzzyNumber(v, f, fuzz)

  /**
    * Make a copy of this Number, with the same nominalValue and factor but with a different nominalValue of fuzziness.
    *
    * @param fo the (optional) fuzziness.
    * @return a Number.
    */
  def make(fo: Option[Fuzziness[Double]]): Number = fo match {
    case Some(_) =>
      FuzzyNumber(nominalValue, factor, fo)
    case None =>
      ExactNumber(nominalValue, factor)
  }

  /**
    * Make a copy of this Number, given the same degree of fuzziness as the original.
    * Only the nominalValue and factor will change.
    * This method should be followed by a call to specialize.
    *
    * @param v  the nominalValue (a Double).
    * @param f  Factor.
    * @param fo optional fuzz.
    * @return either a Number.
    */
  def make(v: Double, f: Factor, fo: Option[Fuzziness[Double]]): Number =
    FuzzyNumber(Value.fromDouble(Some(v)), f, fo)
}

/**
  * The `FuzzyNumber` companion object provides operations and utilities for working with
  * fuzzy numbers, enabling probabilistic and inexact computations. It includes
  * methods for comparison, arithmetic, and adding fuzziness to numbers.
  */
object FuzzyNumber {

  /**
    * Round a Double value to the given number of significant figures, returning a String.
    *
    * @param value   the value to round.
    * @param sigFigs the number of significant figures.
    * @return a String representation rounded to sigFigs significant figures.
    */
  def roundToSigFigs(value: Double, sigFigs: Int): String =
    if value == 0.0 then "0"
    else
      val magnitude = math.floor(math.log10(math.abs(value))).toInt
      val scale = math.pow(10, sigFigs - 1 - magnitude)
      val rounded = math.round(value * scale).toDouble / scale
      val decimals = math.max(0, sigFigs - 1 - magnitude)
      s"%.${decimals}f".format(rounded)

  /**
    * Calculate the appropriate number of significant figures to display given a relative tolerance.
    * We show enough figures so the last digit is uncertain — i.e. 1 extra sig fig beyond the uncertainty.
    *
    * @param tolerance the relative tolerance (e.g. 0.02 for 2%).
    * @return the number of significant figures to display (minimum 1).
    */
  def sigFigsForTolerance(tolerance: Double): Int =
    if tolerance <= 0 then 6 // fallback for zero or negative tolerance
    else math.max(1, -math.floor(math.log10(tolerance)).toInt + 1)

  /**
    * Definition of concrete (implicit) type class object for FuzzyNumber being Fuzzy.
    */
  implicit object NumberIsFuzzy extends Fuzzy[Number] {
    /**
      * Method to determine if x1 and x2 can be considered the same with a probability of p.
      *
      * @param p  a probability between 0 and 1 -- 0 would always result in true; 1 will result in false unless x1 actually is x2.
      * @param x1 a value of X.
      * @param x2 a value of X.
      * @return true if x1 and x2 are considered equal with probability p.
      */
    def same(p: Double)(x1: Number, x2: Number): Boolean =
      x1.doAdd(x2.makeNegative).isProbablyZero(p)
  }

  /**
    * For fuzzy numbers, it's appropriate to use the the normal mechanism for compare, even for NatLog numbers.
    *
    * NOTE, we first invoke same(p)(x, y) to determine if the Numbers are the same in a canonical manner.
    * However, we could actually skip this step and always just invoke the else part of the expression.
    *
    * @param x the first number.
    * @param y the second number.
    * @param confidence the probability criterion.
    * @return an Int representing the order.
    */
  def fuzzyCompare(x: Number, y: Number, confidence: Double = oneSigma): Int =
    if (implicitly[Fuzzy[Number]].same(confidence)(x, y))
      0
    else
      GeneralNumber.plus(x, Number.negate(y)).signum(confidence)

  /**
    * Method to construct an invalid Number.
    *
    * @return Number.apply()
    */
  def apply(): Number =
    Number.apply()

  /**
    * Method to add a FuzzyNumber and a (general) Number.
    *
    * @param x a FuzzyNumber.
    * @param y a Number.
    * @return the sum of x and y.
    */
  def plus(x: FuzzyNumber, y: Number): Number =
    x.alignFactors(y) match {
      case (a: GeneralNumber, b: GeneralNumber) =>
        val (p, q) = a.alignTypes(b)
        (p, q) match {
          case (n: FuzzyNumber, _) =>
            composeDyadic(n, q, p.factor, DyadicOperationPlus, independent = true, None)
          case (_, n: FuzzyNumber) =>
            composeDyadic(n, p, q.factor, DyadicOperationPlus, independent = true, None)
          case (_, _) =>
            p `doAdd` q
        }
      case (number, number1) =>
        throw CoreException(s"cannot add $number and $number1")
    }

  /**
    * Evaluate a dyadic operator, defined by op, on n and q.
    * Parameter independent relates to the calculation of the error bounds of the result.
    *
    * CONSIDER removing this method (merging it with code in GeneralNumber).
    *
    * @param n            the first operand.
    * @param q            the second operand.
    * @param f            the Factor to be used for the result.
    * @param op           the dyadic operation.
    * @param independent  true if the fuzziness of the inputs is independent..
    * @param coefficients an optional Tuple representing the coefficients to scale the fuzz values by.
    *                     For a power operation such as x to the power of y, these will be y/x and ln x respectively.
    *                     For addition or multiplication, they will be 1 and 1.
    * @return a new Number which is the result of operating on n and q as described above.
    */
  private def composeDyadic(n: Number, q: Number, f: Factor, op: DyadicOperation, independent: Boolean, coefficients: Option[(Double, Double)]): Number = n match {
    case x: FuzzyNumber =>
      prepareWithSpecialize(x.composeDyadicFuzzy(q, f)(op, independent, coefficients))
  }

  /**
    * Method to multiply two Numbers, the first a GeneralNumber.
    *
    * CONSIDER why do we have this as well as the times method in GeneralNumber?
    * Perhaps the type of x should be FuzzyNumber.
    *
    * @param x a GeneralNumber.
    * @param y a Number.
    * @return the product of x and y.
    */
  def times(x: GeneralNumber, y: Number): Number =
    x.alignFactors(y) match {
      case (a: GeneralNumber, b: GeneralNumber) =>
        val (p, q) = a.alignTypes(b)
        (p, q) match {
          case (n: FuzzyNumber, _) =>
            composeDyadic(n, q, p.factor, DyadicOperationTimes, independent = x != y, None)
          case (_, n: FuzzyNumber) =>
            composeDyadic(n, p, q.factor, DyadicOperationTimes, independent = x != y, None)
          case (_, _) =>
            p `doMultiply` q
        }
      case (_, _) =>
        throw CoreException(s"cannot multiply $x and $y")
    }

  /**
    * Method to add fuzz to a FuzzyNumber.
    *
    * @param n the Number to be fuzzied.
    * @param f the fuzziness to be added.
    * @return a fuzzied version of n.
    */
  def addFuzz(n: Number, f: Fuzziness[Double]): Number =
    (n.nominalValue, n.fuzz) match {
      case (v, fo) =>
        addFuzz(n, v, fo, f)
    }

  /**
    * Adds fuzziness to a given number.
    *
    * @param number      The input number to which fuzziness will be added.
    * @param v           The value component associated with the resulting fuzzy number.
    * @param fo          An optional initial fuzziness to combine with.
    * @param fAdditional Additional fuzziness to be applied.
    */
  private def addFuzz(number: Number, v: Value, fo: Option[Fuzziness[Double]], fAdditional: Fuzziness[Double]): FuzzyNumber = {
    val combinedFuzz: Option[Fuzziness[Double]] = for (
      f: Fuzziness[Double] <- fo.orElse(Some(AbsoluteFuzz(0.0, Box)));
      p <- number.toNominalDouble;
      g: Fuzziness[Double] <- Fuzziness.combine(p, 0.0, f.style, independent = false)((fo, fAdditional.normalize(p, f.style)))
    ) yield g
    FuzzyNumber(v, number.factor, combinedFuzz)
  }

  /**
    * Raises a FuzzyNumber to the power of a given number.
    *
    * @param number the FuzzyNumber to be raised to a power.
    * @param p      the exponent to which the FuzzyNumber is raised.
    * @return the result of raising the FuzzyNumber to the specified power.
    */
  private def power(number: FuzzyNumber, p: Number): Number =
    composeDyadic(number.scale(PureNumber), p, p.factor, DyadicOperationPower, independent = false, getPowerCoefficients(number, p))

  /**
    * Get the fuzz coefficients for calculating the fuzz on a power operation.
    * According to the "Generalized Power Rule," these coefficients should be y and y ln x, respectively,
    * where x is the magnitude of n and y is the magnitude of p.
    *
    * @param n the number to be raised to power p.
    * @param p the power (exponent) with which to raise n.
    * @return the value of n to the power of p.
    */
  private def getPowerCoefficients(n: Number, p: Number): Option[(Double, Double)] =
    for (z <- n.toNominalDouble; q <- p.toNominalDouble) yield (q, q * math.log(math.abs(z)))

  /**
    *
    * @param confidence the confidence desired. Ignored if isZero is true.
    * @param f the fuzziness.
    * @param x the value to be tested (may be positive or negative).
    * @return true if x is within the tolerance range of f, given confidence level p. Otherwise, false
    */
  private def withinWiggleRoom(confidence: Double, f: Fuzziness[Double], x: Double) =
    f.normalizeShape.wiggle(confidence) > math.abs(x)
}

/**
  * A specific type of exception that is thrown to indicate an error related to fuzzy number operations or validations.
  *
  * @param str The error message that provides details about the exception.
  */
case class FuzzyNumberException(str: String) extends Exception(str)