/*
 * Copyright (c) 2023-2025. Phasmid Software
 */

package com.phasmidsoftware.number.algebra.eager

import cats.implicits.catsSyntaxEq
import cats.kernel.Eq
import com.phasmidsoftware.number.algebra.*
import com.phasmidsoftware.number.algebra.core.*
import com.phasmidsoftware.number.algebra.util.LatexRenderer.LatexRendererOps
import com.phasmidsoftware.number.algebra.util.{AlgebraException, FP, LatexRenderer}
import com.phasmidsoftware.number.core.inner.{Factor, Rational}
import com.phasmidsoftware.number.core.numerical
import com.phasmidsoftware.number.core.numerical.*
import com.phasmidsoftware.number.{algebra, core}
import org.slf4j.{Logger, LoggerFactory}

import scala.util.{Failure, Success, Try}

/**
  * This is a wrapper for a Complex number to demonstrate where it should appear in the type hierarchy (it should extend Solution).
  *
  * @see com.phasmidsoftware.number.core.numerical.Complex
  */
case class Complex(complex: numerical.Complex)(val maybeName: Option[String] = None) extends Solution {
  /**
    * Returns the number of branches in `this`.
    *
    * CONSIDER implement this more generally.
    * For the roots of quadratic equations, the number of branches is 2, since there are two possible solutions.
    * But for nth roots, we would need to support more branches.
    *
    * `branches` corresponds to the number of possible solutions to some equation.
    *
    * @return the number of branches as an integer.
    */
  def branches: Int = 2

  /**
    * @return true.
    */
  def isComplex: Boolean = complex.isComplex

  /**
    * Method to determine the modulus of this Complex number.
    *
    * @return the modulus of this Complex.
    */
  def modulus: Number = complex.modulus

  /**
    * Method to determine the argument (angle) of this Complex number.
    *
    * @return a Number (in radians).
    */
  def argument: Number = complex.argument

  /**
    * Rotate this Complex number by pi/2 counter-clockwise (i.e. multiply by i).
    *
    * @return the value of this * i.
    */
  def rotate: Complex = Complex(complex.rotate)

  /**
    * Method to determine what `Factor`, if there is such, this `NumberLike` object is based on.
    *
    * TODO it's more complicated than this!
    * CONSIDER having a Complex sub-type of Factor.
    *
    * @return an optional `Factor`.
    */
  def maybeFactor: Option[Factor] = complex.maybeFactor

  /**
    * Method to add this Complex to another Complex.
    *
    * @param other the other Complex.
    * @return the sum of the Complexes.
    */
  def doAdd(other: Complex): Complex = Complex(complex.doAdd(other.complex))

  /**
    * Method to multiply this Complex by another Complex.
    *
    * @param other the other Complex.
    * @return the product of the Complexes.
    */
  def doMultiply(other: Complex): Complex = Complex(complex.doMultiply(other.complex))

  /**
    * Determines if the current number is equal to zero.
    *
    * @return true if the number is zero, false otherwise
    */
  def isZero: Boolean = complex.isZero

  /**
    * Determines if the current `Complex` number is both real and of unity magnitude.
    *
    * A `Complex` number is considered to have unity magnitude if its modulus equals one.
    * Additionally, the number must lie on the real axis to satisfy the condition of being real.
    *
    * @return true if the `Complex` number is real and has unity magnitude, false otherwise.
    */
  def isUnity: Boolean = complex.isReal && complex.isUnity

  /**
    * Determines the sign of the Structure value represented by this instance.
    * Returns an integer indicating whether the value is positive, negative, or zero.
    *
    * @return 1 if the value is positive, -1 if the value is negative, and 0 if the value is zero
    */
  def signum: Int = complex.signum

  /**
    * Normalizes the `Complex` instance represented by the current object.
    *
    * This method computes a normalized form of the underlying complex structure,
    * converting it to either a `Complex` or `Eager` representation, depending on the resulting value.
    * If the normalized value is of type `numerical.Complex`, it is converted into a `Complex` instance.
    * Otherwise, if the normalized value is a `Field`, it is wrapped in an `Eager` instance.
    *
    * @return an `Eager` instance that encapsulates the normalized value, either as a `Complex` or another `Eager` representation.
    */
  lazy val normalize: Eager = complex.normalize match {
    case c: numerical.Complex =>
      Complex(c)()
    case x: Field =>
      Eager(x)
  }

  /**
    * Scales the current Complex instance by a given Rational value.
    *
    * This method multiplies the internal representation of the Complex number
    * by the specified Rational value, returning a new Solution instance that represents
    * the resulting scaled value.
    *
    * @param r the Rational value by which to scale the Complex number
    * @return a Complex instance representing the scaled value
    */
  def scale(r: Rational): Solution = Complex(complex.numberProduct(ExactNumber(r)))

  /**
    * Computes and returns the conjugate of the current `Solution` instance.
    *
    * The conjugate represents a value or transformation that is mathematically
    * paired oppositely with the current instance based on the structure and
    * properties of the `Solution` implementation.
    *
    * Normally, the `branch` of the conjugate, added to the current `branch` should equal `branches`.
    *
    * @return a new `Solution` instance representing the conjugate of the current instance
    */
  def conjugate: Solution = copy(complex = complex.conjugate)(None)

  /**
    * Method to render this `Valuable` for presentation to the user.
    *
    * @return a String
    */
  lazy val render: String = maybeName getOrElse complex.render

  /**
    * Determines whether this `Valuable` is exact, i.e., has no approximation.
    *
    * CONSIDER it may be possible that there are non-approximatable entities that are not exact either.
    *
    * The method returns `true` if there is no approximate representation
    * available (i.e., `approximation` is `None`), indicating that the
    * entity is exact. Otherwise, it returns `false`.
    *
    * @return a `Boolean` indicating whether the entity is exact (`true`)
    *         or has an approximation (`false`).
    */
  def isExact: Boolean = complex.isExact

  /**
    * Optionally retrieves a factor associated with this `Valuable` if one exists (this is a Scalar).
    *
    * Factors are components or divisors related to the numerical value represented 
    * by this `Valuable`. If no such factor exists or is applicable, the result will 
    * be `None`.
    *
    * @return an `Option` containing the `Factor` if available, otherwise `None`.
    */
  def maybeFactor(context: Context): Option[Factor] = complex.maybeFactor

  /**
    * If this `Solution` can be represented as a `Structure`, return it wrapped in `Some`, otherwise return `None`.
    * TODO implement imaginary cases.
    *
    * @return an `Option[Structure]`.
    * @note Throws an [[com.phasmidsoftware.number.algebra.util.AlgebraException]] if the complex number is imaginary.
    */
  def toMonotone: Option[Structure] =
    if (complex.isReal) complex.asReal map (x => Eager(x).asMonotone)
    else if (complex.isImaginary) throw AlgebraException("imaginary to Structure not yet implemented")
    else None

  /**
    * Returns the negation of this `Complex` number.
    *
    * The negation operation inverts both the real and imaginary components
    * of the `Complex` instance. This is equivalent to rotating the complex
    * number by 180 degrees in the complex plane.
    *
    * @return a new `Solution` representing the negated value of this `Complex` instance
    */
  lazy val negate: Solution = 
    Complex(complex.rotate.rotate)()

  def +(other: Solution): Solution = other match {
    case Complex(c) =>
      Complex((complex + c).asInstanceOf[numerical.Complex])()
    case _ => throw new UnsupportedOperationException(s"Complex.+(Solution): unexpected input: $this and $other")
  }

  override def eqv(that: Eager): Try[Boolean] = (this, that) match {
    case (Complex(a), Complex(b)) =>
      Success(a.normalize == b.normalize)
    case _ =>
      Failure(AlgebraException(s"Complex.eqv: unexpected input: $this and $that"))
  }

  override def fuzzyEqv(confidence: Double)(that: Eager): Try[Boolean] = (this, that) match {
    case (Complex(a), Complex(b)) => Success(a.isSame(b)) // TODO we lose the value of `p` here (it defaults to 0.5)
    case _ => Failure(AlgebraException(s"Complex.fuzzyEqv: unexpected input: $this, $that"))
  }

  /**
    * @return this `Eager`.
    */
  override val fuzzy: Eager = this

  /**
    * Attempts to compute an approximate representation of the current value.
    *
    * This method provides an optional approximation of the value represented by
    * the implementing class. The approximation may account for uncertainties or
    * computational limitations. By default, this method does not force computation
    * of the approximation unless explicitly requested.
    *
    * @param force a boolean flag indicating whether to force computation of
    *              the approximation. If `true`, the method will attempt to
    *              generate an approximation even if such computation
    *              is resource-intensive or not strictly necessary.
    *
    * @return an `Option` containing the approximate value as a `Real` if available,
    *         or `None` if no approximation can be computed.
    */
  def approximation(force: Boolean): Option[eager.Real] =
    FP.whenever(complex.isReal) {
      val modulus: Number = complex.modulus
      Scalar.createScalar(modulus.nominalValue, modulus.factor, modulus.fuzz).approximation(force)
    }
}

/**
  * Represents a `Solution` that is `Eager`, negatable, and branched with monotonic properties.
  * This trait combines the characteristics of eagerly evaluated values, negatable structures,
  * and entities with multiple branches (or solutions) represented by `Structure`.
  */
trait Solution extends Eager with Negatable[Solution] {

  /**
    * Computes and returns the conjugate of the current `Solution` instance.
    *
    * The conjugate represents a value or transformation that is mathematically
    * paired oppositely with the current instance based on the structure and
    * properties of the `Solution` implementation.
    *
    * Normally, the `branch` of the conjugate, added to the current `branch` should equal `branches`.
    *
    * @return a new `Solution` instance representing the conjugate of the current instance
    */
  def conjugate: Solution

  /**
    * If this `Solution` can be represented as a `Structure`, return it wrapped in `Some`, otherwise return `None`.
    *
    * @return an `Option[Structure]`.
    */
  def toMonotone: Option[Structure]

  /**
    * Adds another `Solution` instance to the current instance, combining their effects or values
    * based on the implementation of the `+` operation in the `Solution` trait.
    *
    * CONSIDER this should be defined in `CanAdd[Solution]` rather than `Solution`.
    * Maybe we could achieve that by defining `Can` as a subtype of `Eager`, rather than of `Structure`.
    *
    * @param other the `Solution` instance to add to the current instance
    * @return a new `Solution` instance representing the result of the addition
    */
  def +(other: Solution): Solution

  /**
    * Scales the current `Solution` instance by a given `Rational` factor.
    * CONSIDER this could be merged with `*`.
    *
    * The scaling operation adjusts the `Solution` based on the value of the provided
    * `Rational` parameter, resulting in a new `Solution` instance that reflects
    * the modification.
    *
    * @param r the `Rational` value by which to scale the current `Solution`
    * @return a new `Solution` instance representing the result of the scaling operation
    */
  def scale(r: Rational): Solution
}

/**
  * Object containing functionality related to `Solution`, including mathematical computations
  * and rendering solutions as LaTeX.
  */
object Solution {

  /**
    * Computes the quadratic offset coefficient for a given index within a cyclic structure.
    *
    * The method maps the index `k` within the range {0, 1, ..., n-1} to an odd position
    * in a `2n`-cycle and calculates a corresponding rational coefficient.
    *
    * @param k the index to map, where `k` is an integer in the range {0, 1, ..., n-1}
    * @param n the total number of branches in the cycle, representing the size of the range
    * @return the quadratic offset coefficient as a `Rational` value
    */
  def quadraticOffsetCoefficient(k: Int, n: Int): Int = if (k == 0) 1 else -1
  // NOTE that I wanted to use something like below but that doesn't actually give the right answers.
//  {
// Map k ∈ {0, 1, ..., n-1} to odd positions in 2n cycle
//    val position = 2 * k + 1  // gives {1, 3, 5, ..., 2n-1}
//    Rational(position, 2 * n) - 1 // gives {-1/2, +1/2, ...}
//  }

  /**
    * LatexRenderer for Solution (general case).
    *
    * Attempts to render based on the concrete type.
    */
  implicit val solutionLatexRenderer: LatexRenderer[Solution] = LatexRenderer.instance {
    case c: Complex => c.toLatex
    case a: Algebraic => a.toLatex
    case s => s.render // Fallback to render method
  }

}

/**
  * Companion object for the `Complex` class.
  *
  * Provides utility methods and typeclass instances related to `Complex`,
  * including factory methods, equality checks, and operator support.
  */
object Complex {
  /**
    * Constructs a new instance of `Complex` from a given `numerical.Complex`.
    *
    * @param x the input of type `numerical.Complex` to be converted into a `Complex` instance.
    * @return a new `Complex` instance created using the given `numerical.Complex`.
    */
  def apply(x: numerical.Complex): Complex = new Complex(x)()

  private val logger: Logger = LoggerFactory.getLogger(getClass)

  // CONSIDER do we need this?
  given DyadicOperator[Complex] = new DyadicOperator[Complex] {
    def op[B <: Complex, Z](f: (Complex, B) => Try[Z])(x: Complex, y: B): Try[Z] = f(x, y)
  }

  given Eq[Complex] = Eq.instance {
    (x, y) =>
      FP.toOptionWithLog(logger.warn("Eq[Complex]", _))(x.eqv(y)).getOrElse(false)
  }

  given FuzzyEq[Complex] = FuzzyEq.instance {
    (x, y, p) =>
      x === y || FP.toOptionWithLog(logger.warn("FuzzyEq[Complex]", _))(x.fuzzyEqv(p)(y)).getOrElse(false)
  }

  /**
    * LatexRenderer for Complex numbers.
    *
    * Renders as a + bi where:
    * - a is the real part
    * - b is the imaginary part
    * - Special cases for 0, purely real, purely imaginary handled
    */
  implicit val complexLatexRenderer: LatexRenderer[Complex] = LatexRenderer.instance { c =>
    val complex = c.complex.asCartesian
    val real = complex.real
    val imag = complex.imag

    // Helper to check if a number is effectively zero
    def isZero(n: com.phasmidsoftware.number.core.numerical.Number): Boolean =
      n.isZero

    // Helper to check if a number is effectively one
    def isOne(n: com.phasmidsoftware.number.core.numerical.Number): Boolean =
      n.isUnity

    // Helper to check if a number is effectively negative one
    def isNegOne(n: com.phasmidsoftware.number.core.numerical.Number): Boolean =
      n == Number.negOne

    // TODO do it with latex
    (isZero(real), isZero(imag)) match {
      case (true, true) => "0"
      case (true, false) =>
        if (isOne(imag)) "i"
        else if (isNegOne(imag)) "-i"
        else s"i$imag"
      case (false, true) =>
        real.render
      case (false, false) =>
        s"$real + i${imag.render}"
    }
  }
}
